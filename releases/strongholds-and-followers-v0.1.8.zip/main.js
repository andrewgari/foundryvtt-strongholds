typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
let $e = !1, Fs = !1;
function Os() {
  $e = !0;
}
Os();
const gt = 1, mt = 2, gr = 4, Is = 8, Ps = 16, Ns = 2, Ls = 4, Bs = 8, qs = 1, Hs = 2, G = Symbol(), mr = !1;
var Rt = Array.isArray, Us = Array.prototype.indexOf, br = Array.from, Ct = Object.defineProperty, ct = Object.getOwnPropertyDescriptor, Vs = Object.getOwnPropertyDescriptors, Gs = Object.prototype, Ws = Array.prototype, yr = Object.getPrototypeOf;
function Ys(e) {
  return e();
}
function Et(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function js() {
  var e, t, r = new Promise((s, n) => {
    e = s, t = n;
  });
  return { promise: r, resolve: e, reject: t };
}
const ne = 2, wr = 4, Dt = 8, Ke = 16, we = 32, Xe = 64, kr = 128, ce = 256, ut = 512, Y = 1024, ue = 2048, Te = 4096, ve = 8192, Ne = 16384, Ft = 32768, Ot = 65536, or = 1 << 17, zs = 1 << 18, It = 1 << 19, Sr = 1 << 20, xt = 1 << 21, Pt = 1 << 22, Ie = 1 << 23, Ge = Symbol("$state"), $s = Symbol("legacy props"), Nt = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Ks() {
  throw new Error("https://svelte.dev/e/await_outside_boundary");
}
function Xs(e) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
function Zs() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Js(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Qs() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function en(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function tn() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function rn(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function sn() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function nn() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function an() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
let ln = !1;
function Cr(e) {
  return e === this.v;
}
function on(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function Er(e) {
  return !on(e, this.v);
}
let H = null;
function ft(e) {
  H = e;
}
function cn(e, t = !1, r) {
  H = {
    p: H,
    c: null,
    e: null,
    s: e,
    x: null,
    l: $e && !t ? { s: null, u: null, $: [] } : null
  };
}
function un(e) {
  var t = (
    /** @type {ComponentContext} */
    H
  ), r = t.e;
  if (r !== null) {
    t.e = null;
    for (var s of r)
      Nr(s);
  }
  return H = t.p, /** @type {T} */
  {};
}
function it() {
  return !$e || H !== null && H.l === null;
}
const fn = /* @__PURE__ */ new WeakMap();
function vn(e) {
  var t = A;
  if (t === null)
    return M.f |= Ie, e;
  if ((t.f & Ft) === 0) {
    if ((t.f & kr) === 0)
      throw !t.parent && e instanceof Error && xr(e), e;
    t.b.error(e);
  } else
    Lt(e, t);
}
function Lt(e, t) {
  for (; t !== null; ) {
    if ((t.f & kr) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (r) {
        e = r;
      }
    t = t.parent;
  }
  throw e instanceof Error && xr(e), e;
}
function xr(e) {
  const t = fn.get(e);
  t && (Ct(e, "message", {
    value: t.message
  }), Ct(e, "stack", {
    value: t.stack
  }));
}
let vt = [];
function dn() {
  var e = vt;
  vt = [], Et(e);
}
function Ar(e) {
  vt.length === 0 && queueMicrotask(dn), vt.push(e);
}
function pn() {
  for (var e = (
    /** @type {Effect} */
    A.b
  ); e !== null && !e.has_pending_snippet(); )
    e = e.parent;
  return e === null && Ks(), e;
}
// @__NO_SIDE_EFFECTS__
function Bt(e) {
  var t = ne | ue, r = M !== null && (M.f & ne) !== 0 ? (
    /** @type {Derived} */
    M
  ) : null;
  return A === null || r !== null && (r.f & ce) !== 0 ? t |= ce : A.f |= It, {
    ctx: H,
    deps: null,
    effects: null,
    equals: Cr,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      G
    ),
    wv: 0,
    parent: r ?? A,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function hn(e, t) {
  let r = (
    /** @type {Effect | null} */
    A
  );
  r === null && Zs();
  var s = (
    /** @type {Boundary} */
    r.b
  ), n = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), a = st(
    /** @type {V} */
    G
  ), i = null, o = !M;
  return Tn(() => {
    try {
      var l = e();
    } catch (_) {
      l = Promise.reject(_);
    }
    var c = () => l;
    n = i?.then(c, c) ?? Promise.resolve(l), i = n;
    var v = (
      /** @type {Batch} */
      W
    ), g = s.pending;
    o && (s.update_pending_count(1), g || v.increment());
    const m = (_, u = void 0) => {
      i = null, g || v.activate(), u ? u !== Nt && (a.f |= Ie, nt(a, u)) : ((a.f & Ie) !== 0 && (a.f ^= Ie), nt(a, _)), o && (s.update_pending_count(-1), g || v.decrement()), Rr();
    };
    if (n.then(m, (_) => m(null, _ || "unknown")), v)
      return () => {
        queueMicrotask(() => v.neuter());
      };
  }), new Promise((l) => {
    function c(v) {
      function g() {
        v === n ? l(a) : c(n);
      }
      v.then(g, g);
    }
    c(n);
  });
}
// @__NO_SIDE_EFFECTS__
function qt(e) {
  const t = /* @__PURE__ */ Bt(e);
  return t.equals = Er, t;
}
function Tr(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var r = 0; r < t.length; r += 1)
      Be(
        /** @type {Effect} */
        t[r]
      );
  }
}
function _n(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & ne) === 0)
      return (
        /** @type {Effect} */
        t
      );
    t = t.parent;
  }
  return null;
}
function Ht(e) {
  var t, r = A;
  Ae(_n(e));
  try {
    Tr(e), t = zr(e);
  } finally {
    Ae(r);
  }
  return t;
}
function Mr(e) {
  var t = Ht(e);
  if (e.equals(t) || (e.v = t, e.wv = Yr()), !qe)
    if (je !== null)
      je.set(e, e.v);
    else {
      var r = (Ee || (e.f & ce) !== 0) && e.deps !== null ? Te : Y;
      ee(e, r);
    }
}
function gn(e, t, r) {
  const s = it() ? Bt : qt;
  if (t.length === 0) {
    r(e.map(s));
    return;
  }
  var n = W, a = (
    /** @type {Effect} */
    A
  ), i = mn(), o = pn();
  Promise.all(t.map((l) => /* @__PURE__ */ hn(l))).then((l) => {
    n?.activate(), i();
    try {
      r([...e.map(s), ...l]);
    } catch (c) {
      (a.f & Ne) === 0 && Lt(c, a);
    }
    n?.deactivate(), Rr();
  }).catch((l) => {
    o.error(l);
  });
}
function mn() {
  var e = A, t = M, r = H;
  return function() {
    Ae(e), _e(t), ft(r);
  };
}
function Rr() {
  Ae(null), _e(null), ft(null);
}
const Ze = /* @__PURE__ */ new Set();
let W = null, je = null, cr = /* @__PURE__ */ new Set(), dt = [];
function Dr() {
  const e = (
    /** @type {() => void} */
    dt.shift()
  );
  dt.length > 0 && queueMicrotask(Dr), e();
}
let tt = [], Ut = null, At = !1;
class rt {
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  #n = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #e = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #c = null;
  /**
   * True if an async effect inside this batch resolved and
   * its parent branch was already deleted
   */
  #u = !1;
  /**
   * Async effects (created inside `async_derived`) encountered during processing.
   * These run after the rest of the batch has updated, since they should
   * always have the latest values
   * @type {Effect[]}
   */
  #r = [];
  /**
   * The same as `#async_effects`, but for effects inside a newly-created
   * `<svelte:boundary>` — these do not prevent the batch from committing
   * @type {Effect[]}
   */
  #i = [];
  /**
   * Template effects and `$effect.pre` effects, which run when
   * a batch is committed
   * @type {Effect[]}
   */
  #s = [];
  /**
   * The same as `#render_effects`, but for `$effect` (which runs after)
   * @type {Effect[]}
   */
  #t = [];
  /**
   * Block effects, which may need to re-run on subsequent flushes
   * in order to update internal sources (e.g. each block items)
   * @type {Effect[]}
   */
  #l = [];
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Effect[]}
   */
  #f = [];
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Effect[]}
   */
  #v = [];
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    tt = [];
    var r = null;
    if (Ze.size > 1) {
      r = /* @__PURE__ */ new Map(), je = /* @__PURE__ */ new Map();
      for (const [a, i] of this.current)
        r.set(a, { v: a.v, wv: a.wv }), a.v = i;
      for (const a of Ze)
        if (a !== this)
          for (const [i, o] of a.#n)
            r.has(i) || (r.set(i, { v: i.v, wv: i.wv }), i.v = o);
    }
    for (const a of t)
      this.#p(a);
    if (this.#r.length === 0 && this.#e === 0) {
      this.#d();
      var s = this.#s, n = this.#t;
      this.#s = [], this.#t = [], this.#l = [], W = null, ur(s), ur(n), W === null ? W = this : Ze.delete(this), this.#c?.resolve();
    } else
      this.#o(this.#s), this.#o(this.#t), this.#o(this.#l);
    if (r) {
      for (const [a, { v: i, wv: o }] of r)
        a.wv <= o && (a.v = i);
      je = null;
    }
    for (const a of this.#r)
      Ye(a);
    for (const a of this.#i)
      Ye(a);
    this.#r = [], this.#i = [];
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   */
  #p(t) {
    t.f ^= Y;
    for (var r = t.first; r !== null; ) {
      var s = r.f, n = (s & (we | Xe)) !== 0, a = n && (s & Y) !== 0, i = a || (s & ve) !== 0 || this.skipped_effects.has(r);
      if (!i && r.fn !== null) {
        if (n)
          r.f ^= Y;
        else if ((s & wr) !== 0)
          this.#t.push(r);
        else if ((s & Y) === 0)
          if ((s & Pt) !== 0) {
            var o = r.b?.pending ? this.#i : this.#r;
            o.push(r);
          } else yt(r) && ((r.f & Ke) !== 0 && this.#l.push(r), Ye(r));
        var l = r.first;
        if (l !== null) {
          r = l;
          continue;
        }
      }
      var c = r.parent;
      for (r = r.next; r === null && c !== null; )
        r = c.next, c = c.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #o(t) {
    for (const r of t)
      ((r.f & ue) !== 0 ? this.#f : this.#v).push(r), ee(r, Y);
    t.length = 0;
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, r) {
    this.#n.has(t) || this.#n.set(t, r), this.current.set(t, t.v);
  }
  activate() {
    W = this;
  }
  deactivate() {
    W = null;
    for (const t of cr)
      if (cr.delete(t), t(), W !== null)
        break;
  }
  neuter() {
    this.#u = !0;
  }
  flush() {
    tt.length > 0 ? bn() : this.#d(), W === this && (this.#e === 0 && Ze.delete(this), this.deactivate());
  }
  /**
   * Append and remove branches to/from the DOM
   */
  #d() {
    if (!this.#u)
      for (const t of this.#a)
        t();
    this.#a.clear();
  }
  increment() {
    this.#e += 1;
  }
  decrement() {
    if (this.#e -= 1, this.#e === 0) {
      for (const t of this.#f)
        ee(t, ue), ze(t);
      for (const t of this.#v)
        ee(t, Te), ze(t);
      this.#s = [], this.#t = [], this.flush();
    } else
      this.deactivate();
  }
  /** @param {() => void} fn */
  add_callback(t) {
    this.#a.add(t);
  }
  settled() {
    return (this.#c ??= js()).promise;
  }
  static ensure() {
    if (W === null) {
      const t = W = new rt();
      Ze.add(W), rt.enqueue(() => {
        W === t && t.flush();
      });
    }
    return W;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    dt.length === 0 && queueMicrotask(Dr), dt.unshift(t);
  }
}
function bn() {
  var e = We;
  At = !0;
  try {
    var t = 0;
    for (fr(!0); tt.length > 0; ) {
      var r = rt.ensure();
      if (t++ > 1e3) {
        var s, n;
        yn();
      }
      r.process(tt), xe.clear();
    }
  } finally {
    At = !1, fr(e), Ut = null;
  }
}
function yn() {
  try {
    tn();
  } catch (e) {
    Lt(e, Ut);
  }
}
let Oe = null;
function ur(e) {
  var t = e.length;
  if (t !== 0) {
    for (var r = 0; r < t; ) {
      var s = e[r++];
      if ((s.f & (Ne | ve)) === 0 && yt(s) && (Oe = [], Ye(s), s.deps === null && s.first === null && s.nodes_start === null && (s.teardown === null && s.ac === null ? Hr(s) : s.fn = null), Oe.length > 0)) {
        xe.clear();
        for (const n of Oe)
          Ye(n);
        Oe = [];
      }
    }
    Oe = null;
  }
}
function ze(e) {
  for (var t = Ut = e; t.parent !== null; ) {
    t = t.parent;
    var r = t.f;
    if (At && t === A && (r & Ke) !== 0)
      return;
    if ((r & (Xe | we)) !== 0) {
      if ((r & Y) === 0) return;
      t.f ^= Y;
    }
  }
  tt.push(t);
}
const xe = /* @__PURE__ */ new Map();
function st(e, t) {
  var r = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: Cr,
    rv: 0,
    wv: 0
  };
  return r;
}
// @__NO_SIDE_EFFECTS__
function Ce(e, t) {
  const r = st(e);
  return Dn(r), r;
}
// @__NO_SIDE_EFFECTS__
function Fr(e, t = !1, r = !0) {
  const s = st(e);
  return t || (s.equals = Er), $e && r && H !== null && H.l !== null && (H.l.s ??= []).push(s), s;
}
function be(e, t, r = !1) {
  M !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!he || (M.f & or) !== 0) && it() && (M.f & (ne | Ke | Pt | or)) !== 0 && !ye?.includes(e) && an();
  let s = r ? Ve(t) : t;
  return nt(e, s);
}
function nt(e, t) {
  if (!e.equals(t)) {
    var r = e.v;
    qe ? xe.set(e, t) : xe.set(e, r), e.v = t;
    var s = rt.ensure();
    s.capture(e, r), (e.f & ne) !== 0 && ((e.f & ue) !== 0 && Ht(
      /** @type {Derived} */
      e
    ), ee(e, (e.f & ce) === 0 ? Y : Te)), e.wv = Yr(), Or(e, ue), it() && A !== null && (A.f & Y) !== 0 && (A.f & (we | Xe)) === 0 && (oe === null ? Fn([e]) : oe.push(e));
  }
  return t;
}
function kt(e) {
  be(e, e.v + 1);
}
function Or(e, t) {
  var r = e.reactions;
  if (r !== null)
    for (var s = it(), n = r.length, a = 0; a < n; a++) {
      var i = r[a], o = i.f;
      if (!(!s && i === A)) {
        var l = (o & ue) === 0;
        l && ee(i, t), (o & ne) !== 0 ? Or(
          /** @type {Derived} */
          i,
          Te
        ) : l && ((o & Ke) !== 0 && Oe !== null && Oe.push(
          /** @type {Effect} */
          i
        ), ze(
          /** @type {Effect} */
          i
        ));
      }
    }
}
function Ve(e) {
  if (typeof e != "object" || e === null || Ge in e)
    return e;
  const t = yr(e);
  if (t !== Gs && t !== Ws)
    return e;
  var r = /* @__PURE__ */ new Map(), s = Rt(e), n = /* @__PURE__ */ Ce(0), a = Pe, i = (o) => {
    if (Pe === a)
      return o();
    var l = M, c = Pe;
    _e(null), dr(a);
    var v = o();
    return _e(l), dr(c), v;
  };
  return s && r.set("length", /* @__PURE__ */ Ce(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(o, l, c) {
        (!("value" in c) || c.configurable === !1 || c.enumerable === !1 || c.writable === !1) && sn();
        var v = r.get(l);
        return v === void 0 ? v = i(() => {
          var g = /* @__PURE__ */ Ce(c.value);
          return r.set(l, g), g;
        }) : be(v, c.value, !0), !0;
      },
      deleteProperty(o, l) {
        var c = r.get(l);
        if (c === void 0) {
          if (l in o) {
            const v = i(() => /* @__PURE__ */ Ce(G));
            r.set(l, v), kt(n);
          }
        } else
          be(c, G), kt(n);
        return !0;
      },
      get(o, l, c) {
        if (l === Ge)
          return e;
        var v = r.get(l), g = l in o;
        if (v === void 0 && (!g || ct(o, l)?.writable) && (v = i(() => {
          var _ = Ve(g ? o[l] : G), u = /* @__PURE__ */ Ce(_);
          return u;
        }), r.set(l, v)), v !== void 0) {
          var m = f(v);
          return m === G ? void 0 : m;
        }
        return Reflect.get(o, l, c);
      },
      getOwnPropertyDescriptor(o, l) {
        var c = Reflect.getOwnPropertyDescriptor(o, l);
        if (c && "value" in c) {
          var v = r.get(l);
          v && (c.value = f(v));
        } else if (c === void 0) {
          var g = r.get(l), m = g?.v;
          if (g !== void 0 && m !== G)
            return {
              enumerable: !0,
              configurable: !0,
              value: m,
              writable: !0
            };
        }
        return c;
      },
      has(o, l) {
        if (l === Ge)
          return !0;
        var c = r.get(l), v = c !== void 0 && c.v !== G || Reflect.has(o, l);
        if (c !== void 0 || A !== null && (!v || ct(o, l)?.writable)) {
          c === void 0 && (c = i(() => {
            var m = v ? Ve(o[l]) : G, _ = /* @__PURE__ */ Ce(m);
            return _;
          }), r.set(l, c));
          var g = f(c);
          if (g === G)
            return !1;
        }
        return v;
      },
      set(o, l, c, v) {
        var g = r.get(l), m = l in o;
        if (s && l === "length")
          for (var _ = c; _ < /** @type {Source<number>} */
          g.v; _ += 1) {
            var u = r.get(_ + "");
            u !== void 0 ? be(u, G) : _ in o && (u = i(() => /* @__PURE__ */ Ce(G)), r.set(_ + "", u));
          }
        if (g === void 0)
          (!m || ct(o, l)?.writable) && (g = i(() => /* @__PURE__ */ Ce(void 0)), be(g, Ve(c)), r.set(l, g));
        else {
          m = g.v !== G;
          var C = i(() => Ve(c));
          be(g, C);
        }
        var k = Reflect.getOwnPropertyDescriptor(o, l);
        if (k?.set && k.set.call(v, c), !m) {
          if (s && typeof l == "string") {
            var I = (
              /** @type {Source<number>} */
              r.get("length")
            ), p = Number(l);
            Number.isInteger(p) && p >= I.v && be(I, p + 1);
          }
          kt(n);
        }
        return !0;
      },
      ownKeys(o) {
        f(n);
        var l = Reflect.ownKeys(o).filter((g) => {
          var m = r.get(g);
          return m === void 0 || m.v !== G;
        });
        for (var [c, v] of r)
          v.v !== G && !(c in o) && l.push(c);
        return l;
      },
      setPrototypeOf() {
        nn();
      }
    }
  );
}
var wn, kn, Sn;
function Vt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function pt(e) {
  return kn.call(e);
}
// @__NO_SIDE_EFFECTS__
function bt(e) {
  return Sn.call(e);
}
function d(e, t) {
  return /* @__PURE__ */ pt(e);
}
function Je(e, t) {
  {
    var r = (
      /** @type {DocumentFragment} */
      /* @__PURE__ */ pt(
        /** @type {Node} */
        e
      )
    );
    return r instanceof Comment && r.data === "" ? /* @__PURE__ */ bt(r) : r;
  }
}
function w(e, t = 1, r = !1) {
  let s = e;
  for (; t--; )
    s = /** @type {TemplateNode} */
    /* @__PURE__ */ bt(s);
  return s;
}
function Cn(e) {
  e.textContent = "";
}
function Ir() {
  return !1;
}
function Gt(e) {
  var t = M, r = A;
  _e(null), Ae(null);
  try {
    return e();
  } finally {
    _e(t), Ae(r);
  }
}
function Pr(e) {
  A === null && M === null && en(), M !== null && (M.f & ce) !== 0 && A === null && Qs(), qe && Js();
}
function En(e, t) {
  var r = t.last;
  r === null ? t.last = t.first = e : (r.next = e, e.prev = r, t.last = e);
}
function Le(e, t, r, s = !0) {
  var n = A;
  n !== null && (n.f & ve) !== 0 && (e |= ve);
  var a = {
    ctx: H,
    deps: null,
    nodes_start: null,
    nodes_end: null,
    f: e | ue,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: n,
    b: n && n.b,
    prev: null,
    teardown: null,
    transitions: null,
    wv: 0,
    ac: null
  };
  if (r)
    try {
      Ye(a), a.f |= Ft;
    } catch (l) {
      throw Be(a), l;
    }
  else t !== null && ze(a);
  var i = r && a.deps === null && a.first === null && a.nodes_start === null && a.teardown === null && (a.f & It) === 0;
  if (!i && s && (n !== null && En(a, n), M !== null && (M.f & ne) !== 0 && (e & Xe) === 0)) {
    var o = (
      /** @type {Derived} */
      M
    );
    (o.effects ??= []).push(a);
  }
  return a;
}
function xn(e) {
  const t = Le(Dt, null, !1);
  return ee(t, Y), t.teardown = e, t;
}
function Tt(e) {
  Pr();
  var t = (
    /** @type {Effect} */
    A.f
  ), r = !M && (t & we) !== 0 && (t & Ft) === 0;
  if (r) {
    var s = (
      /** @type {ComponentContext} */
      H
    );
    (s.e ??= []).push(e);
  } else
    return Nr(e);
}
function Nr(e) {
  return Le(wr | Sr, e, !1);
}
function An(e) {
  return Pr(), Le(Dt | Sr, e, !0);
}
function Tn(e) {
  return Le(Pt | It, e, !0);
}
function q(e, t = [], r = []) {
  gn(t, r, (s) => {
    Le(Dt, () => e(...s.map(f)), !0);
  });
}
function Lr(e, t = 0) {
  var r = Le(Ke | t, e, !0);
  return r;
}
function ht(e, t = !0) {
  return Le(we, e, !0, t);
}
function Br(e) {
  var t = e.teardown;
  if (t !== null) {
    const r = qe, s = M;
    vr(!0), _e(null);
    try {
      t.call(null);
    } finally {
      vr(r), _e(s);
    }
  }
}
function qr(e, t = !1) {
  var r = e.first;
  for (e.first = e.last = null; r !== null; ) {
    const n = r.ac;
    n !== null && Gt(() => {
      n.abort(Nt);
    });
    var s = r.next;
    (r.f & Xe) !== 0 ? r.parent = null : Be(r, t), r = s;
  }
}
function Mn(e) {
  for (var t = e.first; t !== null; ) {
    var r = t.next;
    (t.f & we) === 0 && Be(t), t = r;
  }
}
function Be(e, t = !0) {
  var r = !1;
  (t || (e.f & zs) !== 0) && e.nodes_start !== null && e.nodes_end !== null && (Rn(
    e.nodes_start,
    /** @type {TemplateNode} */
    e.nodes_end
  ), r = !0), qr(e, t && !r), _t(e, 0), ee(e, Ne);
  var s = e.transitions;
  if (s !== null)
    for (const a of s)
      a.stop();
  Br(e);
  var n = e.parent;
  n !== null && n.first !== null && Hr(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes_start = e.nodes_end = e.ac = null;
}
function Rn(e, t) {
  for (; e !== null; ) {
    var r = e === t ? null : (
      /** @type {TemplateNode} */
      /* @__PURE__ */ bt(e)
    );
    e.remove(), e = r;
  }
}
function Hr(e) {
  var t = e.parent, r = e.prev, s = e.next;
  r !== null && (r.next = s), s !== null && (s.prev = r), t !== null && (t.first === e && (t.first = s), t.last === e && (t.last = r));
}
function Ur(e, t) {
  var r = [];
  Wt(e, r, !0), Vr(r, () => {
    Be(e), t && t();
  });
}
function Vr(e, t) {
  var r = e.length;
  if (r > 0) {
    var s = () => --r || t();
    for (var n of e)
      n.out(s);
  } else
    t();
}
function Wt(e, t, r) {
  if ((e.f & ve) === 0) {
    if (e.f ^= ve, e.transitions !== null)
      for (const i of e.transitions)
        (i.is_global || r) && t.push(i);
    for (var s = e.first; s !== null; ) {
      var n = s.next, a = (s.f & Ot) !== 0 || (s.f & we) !== 0;
      Wt(s, t, a ? r : !1), s = n;
    }
  }
}
function Yt(e) {
  Gr(e, !0);
}
function Gr(e, t) {
  if ((e.f & ve) !== 0) {
    e.f ^= ve, (e.f & Y) === 0 && (ee(e, ue), ze(e));
    for (var r = e.first; r !== null; ) {
      var s = r.next, n = (r.f & Ot) !== 0 || (r.f & we) !== 0;
      Gr(r, n ? t : !1), r = s;
    }
    if (e.transitions !== null)
      for (const a of e.transitions)
        (a.is_global || t) && a.in();
  }
}
let We = !1;
function fr(e) {
  We = e;
}
let qe = !1;
function vr(e) {
  qe = e;
}
let M = null, he = !1;
function _e(e) {
  M = e;
}
let A = null;
function Ae(e) {
  A = e;
}
let ye = null;
function Dn(e) {
  M !== null && (ye === null ? ye = [e] : ye.push(e));
}
let X = null, se = 0, oe = null;
function Fn(e) {
  oe = e;
}
let Wr = 1, at = 0, Pe = at;
function dr(e) {
  Pe = e;
}
let Ee = !1;
function Yr() {
  return ++Wr;
}
function yt(e) {
  var t = e.f;
  if ((t & ue) !== 0)
    return !0;
  if ((t & Te) !== 0) {
    var r = e.deps, s = (t & ce) !== 0;
    if (r !== null) {
      var n, a, i = (t & ut) !== 0, o = s && A !== null && !Ee, l = r.length;
      if ((i || o) && (A === null || (A.f & Ne) === 0)) {
        var c = (
          /** @type {Derived} */
          e
        ), v = c.parent;
        for (n = 0; n < l; n++)
          a = r[n], (i || !a?.reactions?.includes(c)) && (a.reactions ??= []).push(c);
        i && (c.f ^= ut), o && v !== null && (v.f & ce) === 0 && (c.f ^= ce);
      }
      for (n = 0; n < l; n++)
        if (a = r[n], yt(
          /** @type {Derived} */
          a
        ) && Mr(
          /** @type {Derived} */
          a
        ), a.wv > e.wv)
          return !0;
    }
    (!s || A !== null && !Ee) && ee(e, Y);
  }
  return !1;
}
function jr(e, t, r = !0) {
  var s = e.reactions;
  if (s !== null && !ye?.includes(e))
    for (var n = 0; n < s.length; n++) {
      var a = s[n];
      (a.f & ne) !== 0 ? jr(
        /** @type {Derived} */
        a,
        t,
        !1
      ) : t === a && (r ? ee(a, ue) : (a.f & Y) !== 0 && ee(a, Te), ze(
        /** @type {Effect} */
        a
      ));
    }
}
function zr(e) {
  var t = X, r = se, s = oe, n = M, a = Ee, i = ye, o = H, l = he, c = Pe, v = e.f;
  X = /** @type {null | Value[]} */
  null, se = 0, oe = null, Ee = (v & ce) !== 0 && (he || !We || M === null), M = (v & (we | Xe)) === 0 ? e : null, ye = null, ft(e.ctx), he = !1, Pe = ++at, e.ac !== null && (Gt(() => {
    e.ac.abort(Nt);
  }), e.ac = null);
  try {
    e.f |= xt;
    var g = (
      /** @type {Function} */
      e.fn
    ), m = g(), _ = e.deps;
    if (X !== null) {
      var u;
      if (_t(e, se), _ !== null && se > 0)
        for (_.length = se + X.length, u = 0; u < X.length; u++)
          _[se + u] = X[u];
      else
        e.deps = _ = X;
      if (!Ee || // Deriveds that already have reactions can cleanup, so we still add them as reactions
      (v & ne) !== 0 && /** @type {import('#client').Derived} */
      e.reactions !== null)
        for (u = se; u < _.length; u++)
          (_[u].reactions ??= []).push(e);
    } else _ !== null && se < _.length && (_t(e, se), _.length = se);
    if (it() && oe !== null && !he && _ !== null && (e.f & (ne | Te | ue)) === 0)
      for (u = 0; u < /** @type {Source[]} */
      oe.length; u++)
        jr(
          oe[u],
          /** @type {Effect} */
          e
        );
    return n !== null && n !== e && (at++, oe !== null && (s === null ? s = oe : s.push(.../** @type {Source[]} */
    oe))), (e.f & Ie) !== 0 && (e.f ^= Ie), m;
  } catch (C) {
    return vn(C);
  } finally {
    e.f ^= xt, X = t, se = r, oe = s, M = n, Ee = a, ye = i, ft(o), he = l, Pe = c;
  }
}
function On(e, t) {
  let r = t.reactions;
  if (r !== null) {
    var s = Us.call(r, e);
    if (s !== -1) {
      var n = r.length - 1;
      n === 0 ? r = t.reactions = null : (r[s] = r[n], r.pop());
    }
  }
  r === null && (t.f & ne) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (X === null || !X.includes(t)) && (ee(t, Te), (t.f & (ce | ut)) === 0 && (t.f ^= ut), Tr(
    /** @type {Derived} **/
    t
  ), _t(
    /** @type {Derived} **/
    t,
    0
  ));
}
function _t(e, t) {
  var r = e.deps;
  if (r !== null)
    for (var s = t; s < r.length; s++)
      On(e, r[s]);
}
function Ye(e) {
  var t = e.f;
  if ((t & Ne) === 0) {
    ee(e, Y);
    var r = A, s = We;
    A = e, We = !0;
    try {
      (t & Ke) !== 0 ? Mn(e) : qr(e), Br(e);
      var n = zr(e);
      e.teardown = typeof n == "function" ? n : null, e.wv = Wr;
      var a;
      mr && Fs && (e.f & ue) !== 0 && e.deps;
    } finally {
      We = s, A = r;
    }
  }
}
function f(e) {
  var t = e.f, r = (t & ne) !== 0;
  if (M !== null && !he) {
    var s = A !== null && (A.f & Ne) !== 0;
    if (!s && !ye?.includes(e)) {
      var n = M.deps;
      if ((M.f & xt) !== 0)
        e.rv < at && (e.rv = at, X === null && n !== null && n[se] === e ? se++ : X === null ? X = [e] : (!Ee || !X.includes(e)) && X.push(e));
      else {
        (M.deps ??= []).push(e);
        var a = e.reactions;
        a === null ? e.reactions = [M] : a.includes(M) || a.push(M);
      }
    }
  } else if (r && /** @type {Derived} */
  e.deps === null && /** @type {Derived} */
  e.effects === null) {
    var i = (
      /** @type {Derived} */
      e
    ), o = i.parent;
    o !== null && (o.f & ce) === 0 && (i.f ^= ce);
  }
  if (qe) {
    if (xe.has(e))
      return xe.get(e);
    if (r) {
      i = /** @type {Derived} */
      e;
      var l = i.v;
      return ((i.f & Y) === 0 && i.reactions !== null || $r(i)) && (l = Ht(i)), xe.set(i, l), l;
    }
  } else if (r) {
    if (i = /** @type {Derived} */
    e, je?.has(i))
      return je.get(i);
    yt(i) && Mr(i);
  }
  if ((e.f & Ie) !== 0)
    throw e.v;
  return e.v;
}
function $r(e) {
  if (e.v === G) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (xe.has(t) || (t.f & ne) !== 0 && $r(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Kr(e) {
  var t = he;
  try {
    return he = !0, e();
  } finally {
    he = t;
  }
}
const In = -7169;
function ee(e, t) {
  e.f = e.f & In | t;
}
function Pn(e) {
  if (!(typeof e != "object" || !e || e instanceof EventTarget)) {
    if (Ge in e)
      Mt(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        const r = e[t];
        typeof r == "object" && r && Ge in r && Mt(r);
      }
  }
}
function Mt(e, t = /* @__PURE__ */ new Set()) {
  if (typeof e == "object" && e !== null && // We don't want to traverse DOM elements
  !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let s in e)
      try {
        Mt(e[s], t);
      } catch {
      }
    const r = yr(e);
    if (r !== Object.prototype && r !== Array.prototype && r !== Map.prototype && r !== Set.prototype && r !== Date.prototype) {
      const s = Vs(r);
      for (let n in s) {
        const a = s[n].get;
        if (a)
          try {
            a.call(e);
          } catch {
          }
      }
    }
  }
}
function Nn(e, t, r, s = {}) {
  function n(a) {
    if (s.capture || Ln.call(t, a), !a.cancelBubble)
      return Gt(() => r?.call(this, a));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? Ar(() => {
    t.addEventListener(e, n, s);
  }) : t.addEventListener(e, n, s), n;
}
function Qe(e, t, r, s, n) {
  var a = { capture: s, passive: n }, i = Nn(e, t, r, a);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && xn(() => {
    t.removeEventListener(e, i, a);
  });
}
let pr = null;
function Ln(e) {
  var t = this, r = (
    /** @type {Node} */
    t.ownerDocument
  ), s = e.type, n = e.composedPath?.() || [], a = (
    /** @type {null | Element} */
    n[0] || e.target
  );
  pr = e;
  var i = 0, o = pr === e && e.__root;
  if (o) {
    var l = n.indexOf(o);
    if (l !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var c = n.indexOf(t);
    if (c === -1)
      return;
    l <= c && (i = l);
  }
  if (a = /** @type {Element} */
  n[i] || e.target, a !== t) {
    Ct(e, "currentTarget", {
      configurable: !0,
      get() {
        return a || r;
      }
    });
    var v = M, g = A;
    _e(null), Ae(null);
    try {
      for (var m, _ = []; a !== null; ) {
        var u = a.assignedSlot || a.parentNode || /** @type {any} */
        a.host || null;
        try {
          var C = a["__" + s];
          if (C != null && (!/** @type {any} */
          a.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === a))
            if (Rt(C)) {
              var [k, ...I] = C;
              k.apply(a, [e, ...I]);
            } else
              C.call(a, e);
        } catch (p) {
          m ? _.push(p) : m = p;
        }
        if (e.cancelBubble || u === t || u === null)
          break;
        a = u;
      }
      if (m) {
        for (let p of _)
          queueMicrotask(() => {
            throw p;
          });
        throw m;
      }
    } finally {
      e.__root = t, delete e.currentTarget, _e(v), Ae(g);
    }
  }
}
function Bn(e) {
  var t = document.createElement("template");
  return t.innerHTML = e.replaceAll("<!>", "<!---->"), t.content;
}
function hr(e, t) {
  var r = (
    /** @type {Effect} */
    A
  );
  r.nodes_start === null && (r.nodes_start = e, r.nodes_end = t);
}
// @__NO_SIDE_EFFECTS__
function T(e, t) {
  var r = (t & qs) !== 0, s = (t & Hs) !== 0, n, a = !e.startsWith("<!>");
  return () => {
    n === void 0 && (n = Bn(a ? e : "<!>" + e), r || (n = /** @type {Node} */
    /* @__PURE__ */ pt(n)));
    var i = (
      /** @type {TemplateNode} */
      s || wn ? document.importNode(n, !0) : n.cloneNode(!0)
    );
    if (r) {
      var o = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ pt(i)
      ), l = (
        /** @type {TemplateNode} */
        i.lastChild
      );
      hr(o, l);
    } else
      hr(i, i);
    return i;
  };
}
function x(e, t) {
  e !== null && e.before(
    /** @type {Node} */
    t
  );
}
function O(e, t) {
  var r = t == null ? "" : typeof t == "object" ? t + "" : t;
  r !== (e.__t ??= e.nodeValue) && (e.__t = r, e.nodeValue = r + "");
}
function qn(e) {
  H === null && Xs(), $e && H.l !== null ? Hn(H).m.push(e) : Tt(() => {
    const t = Kr(e);
    if (typeof t == "function") return (
      /** @type {() => void} */
      t
    );
  });
}
function Hn(e) {
  var t = (
    /** @type {ComponentContextLegacy} */
    e.l
  );
  return t.u ??= { a: [], b: [], m: [] };
}
function N(e, t, r = !1) {
  var s = e, n = null, a = null, i = G, o = r ? Ot : 0, l = !1;
  const c = (_, u = !0) => {
    l = !0, m(u, _);
  };
  var v = null;
  function g() {
    v !== null && (v.lastChild.remove(), s.before(v), v = null);
    var _ = i ? n : a, u = i ? a : n;
    _ && Yt(_), u && Ur(u, () => {
      i ? a = null : n = null;
    });
  }
  const m = (_, u) => {
    if (i !== (i = _)) {
      var C = Ir(), k = s;
      if (C && (v = document.createDocumentFragment(), v.append(k = Vt())), i ? n ??= u && ht(() => u(k)) : a ??= u && ht(() => u(k)), C) {
        var I = (
          /** @type {Batch} */
          W
        ), p = i ? n : a, b = i ? a : n;
        p && I.skipped_effects.delete(p), b && I.skipped_effects.add(b), I.add_callback(g);
      } else
        g();
    }
  };
  Lr(() => {
    l = !1, t(c), l || m(null, null);
  }, o);
}
function De(e, t) {
  return t;
}
function Un(e, t, r) {
  for (var s = e.items, n = [], a = t.length, i = 0; i < a; i++)
    Wt(t[i].e, n, !0);
  var o = a > 0 && n.length === 0 && r !== null;
  if (o) {
    var l = (
      /** @type {Element} */
      /** @type {Element} */
      r.parentNode
    );
    Cn(l), l.append(
      /** @type {Element} */
      r
    ), s.clear(), pe(e, t[0].prev, t[a - 1].next);
  }
  Vr(n, () => {
    for (var c = 0; c < a; c++) {
      var v = t[c];
      o || (s.delete(v.k), pe(e, v.prev, v.next)), Be(v.e, !o);
    }
  });
}
function Fe(e, t, r, s, n, a = null) {
  var i = e, o = { flags: t, items: /* @__PURE__ */ new Map(), first: null }, l = (t & gr) !== 0;
  if (l) {
    var c = (
      /** @type {Element} */
      e
    );
    i = c.appendChild(Vt());
  }
  var v = null, g = !1, m = /* @__PURE__ */ new Map(), _ = /* @__PURE__ */ qt(() => {
    var I = r();
    return Rt(I) ? I : I == null ? [] : br(I);
  }), u, C;
  function k() {
    Vn(
      C,
      u,
      o,
      m,
      i,
      n,
      t,
      s,
      r
    ), a !== null && (u.length === 0 ? v ? Yt(v) : v = ht(() => a(i)) : v !== null && Ur(v, () => {
      v = null;
    }));
  }
  Lr(() => {
    C ??= /** @type {Effect} */
    A, u = /** @type {V[]} */
    f(_);
    var I = u.length;
    if (!(g && I === 0)) {
      g = I === 0;
      var p, b, F, E;
      if (Ir()) {
        var S = /* @__PURE__ */ new Set(), R = (
          /** @type {Batch} */
          W
        );
        for (b = 0; b < I; b += 1) {
          F = u[b], E = s(F, b);
          var te = o.items.get(E) ?? m.get(E);
          te ? (t & (gt | mt)) !== 0 && Xr(te, F, b, t) : (p = Zr(
            null,
            o,
            null,
            null,
            F,
            E,
            b,
            n,
            t,
            r,
            !0
          ), m.set(E, p)), S.add(E);
        }
        for (const [P, ke] of o.items)
          S.has(P) || R.skipped_effects.add(ke.e);
        R.add_callback(k);
      } else
        k();
      f(_);
    }
  });
}
function Vn(e, t, r, s, n, a, i, o, l) {
  var c = (i & Is) !== 0, v = (i & (gt | mt)) !== 0, g = t.length, m = r.items, _ = r.first, u = _, C, k = null, I, p = [], b = [], F, E, S, R;
  if (c)
    for (R = 0; R < g; R += 1)
      F = t[R], E = o(F, R), S = m.get(E), S !== void 0 && (S.a?.measure(), (I ??= /* @__PURE__ */ new Set()).add(S));
  for (R = 0; R < g; R += 1) {
    if (F = t[R], E = o(F, R), S = m.get(E), S === void 0) {
      var te = s.get(E);
      if (te !== void 0) {
        s.delete(E), m.set(E, te);
        var P = k ? k.next : u;
        pe(r, k, te), pe(r, te, P), St(te, P, n), k = te;
      } else {
        var ke = u ? (
          /** @type {TemplateNode} */
          u.e.nodes_start
        ) : n;
        k = Zr(
          ke,
          r,
          k,
          k === null ? r.first : k.next,
          F,
          E,
          R,
          a,
          i,
          l
        );
      }
      m.set(E, k), p = [], b = [], u = k.next;
      continue;
    }
    if (v && Xr(S, F, R, i), (S.e.f & ve) !== 0 && (Yt(S.e), c && (S.a?.unfix(), (I ??= /* @__PURE__ */ new Set()).delete(S))), S !== u) {
      if (C !== void 0 && C.has(S)) {
        if (p.length < b.length) {
          var Se = b[0], re;
          k = Se.prev;
          var U = p[0], h = p[p.length - 1];
          for (re = 0; re < p.length; re += 1)
            St(p[re], Se, n);
          for (re = 0; re < b.length; re += 1)
            C.delete(b[re]);
          pe(r, U.prev, h.next), pe(r, k, U), pe(r, h, Se), u = Se, k = h, R -= 1, p = [], b = [];
        } else
          C.delete(S), St(S, u, n), pe(r, S.prev, S.next), pe(r, S, k === null ? r.first : k.next), pe(r, k, S), k = S;
        continue;
      }
      for (p = [], b = []; u !== null && u.k !== E; )
        (u.e.f & ve) === 0 && (C ??= /* @__PURE__ */ new Set()).add(u), b.push(u), u = u.next;
      if (u === null)
        continue;
      S = u;
    }
    p.push(S), k = S, u = S.next;
  }
  if (u !== null || C !== void 0) {
    for (var j = C === void 0 ? [] : br(C); u !== null; )
      (u.e.f & ve) === 0 && j.push(u), u = u.next;
    var ae = j.length;
    if (ae > 0) {
      var He = (i & gr) !== 0 && g === 0 ? n : null;
      if (c) {
        for (R = 0; R < ae; R += 1)
          j[R].a?.measure();
        for (R = 0; R < ae; R += 1)
          j[R].a?.fix();
      }
      Un(r, j, He);
    }
  }
  c && Ar(() => {
    if (I !== void 0)
      for (S of I)
        S.a?.apply();
  }), e.first = r.first && r.first.e, e.last = k && k.e;
  for (var lt of s.values())
    Be(lt.e);
  s.clear();
}
function Xr(e, t, r, s) {
  (s & gt) !== 0 && nt(e.v, t), (s & mt) !== 0 ? nt(
    /** @type {Value<number>} */
    e.i,
    r
  ) : e.i = r;
}
function Zr(e, t, r, s, n, a, i, o, l, c, v) {
  var g = (l & gt) !== 0, m = (l & Ps) === 0, _ = g ? m ? /* @__PURE__ */ Fr(n, !1, !1) : st(n) : n, u = (l & mt) === 0 ? i : st(i), C = {
    i: u,
    v: _,
    k: a,
    a: null,
    // @ts-expect-error
    e: null,
    prev: r,
    next: s
  };
  try {
    if (e === null) {
      var k = document.createDocumentFragment();
      k.append(e = Vt());
    }
    return C.e = ht(() => o(
      /** @type {Node} */
      e,
      _,
      u,
      c
    ), ln), C.e.prev = r && r.e, C.e.next = s && s.e, r === null ? v || (t.first = C) : (r.next = C, r.e.next = C.e), s !== null && (s.prev = C, s.e.prev = C.e), C;
  } finally {
  }
}
function St(e, t, r) {
  for (var s = e.next ? (
    /** @type {TemplateNode} */
    e.next.e.nodes_start
  ) : r, n = t ? (
    /** @type {TemplateNode} */
    t.e.nodes_start
  ) : r, a = (
    /** @type {TemplateNode} */
    e.e.nodes_start
  ); a !== null && a !== s; ) {
    var i = (
      /** @type {TemplateNode} */
      /* @__PURE__ */ bt(a)
    );
    n.before(a), a = i;
  }
}
function pe(e, t, r) {
  t === null ? e.first = r : (t.next = r, t.e.next = r && r.e), r !== null && (r.prev = t, r.e.prev = t && t.e);
}
function Gn(e, t, r) {
  var s = e == null ? "" : "" + e;
  return s = s ? s + " " + t : t, s === "" ? null : s;
}
function Wn(e, t, r, s, n, a) {
  var i = e.__className;
  if (i !== r || i === void 0) {
    var o = Gn(r, s);
    o == null ? e.removeAttribute("class") : e.className = o, e.__className = r;
  }
  return a;
}
function et(e) {
  return function(...t) {
    var r = (
      /** @type {Event} */
      t[0]
    );
    return r.preventDefault(), e?.apply(this, t);
  };
}
function Yn(e = !1) {
  const t = (
    /** @type {ComponentContextLegacy} */
    H
  ), r = t.l.u;
  if (!r) return;
  let s = () => Pn(t.s);
  if (e) {
    let n = 0, a = (
      /** @type {Record<string, any>} */
      {}
    );
    const i = /* @__PURE__ */ Bt(() => {
      let o = !1;
      const l = t.s;
      for (const c in l)
        l[c] !== a[c] && (a[c] = l[c], o = !0);
      return o && n++, n;
    });
    s = () => f(i);
  }
  r.b.length && An(() => {
    _r(t, s), Et(r.b);
  }), Tt(() => {
    const n = Kr(() => r.m.map(Ys));
    return () => {
      for (const a of n)
        typeof a == "function" && a();
    };
  }), r.a.length && Tt(() => {
    _r(t, s), Et(r.a);
  });
}
function _r(e, t) {
  if (e.l.s)
    for (const r of e.l.s) f(r);
  t();
}
let ot = !1;
function jn(e) {
  var t = ot;
  try {
    return ot = !1, [e(), ot];
  } finally {
    ot = t;
  }
}
function zn(e, t, r, s) {
  var n = !$e || (r & Ns) !== 0, a = (r & Bs) !== 0, i = (
    /** @type {V} */
    s
  ), o = !0, l = () => (o && (o = !1, i = /** @type {V} */
  s), i), c;
  {
    var v = Ge in e || $s in e;
    c = ct(e, t)?.set ?? (v && t in e ? (p) => e[t] = p : void 0);
  }
  var g, m = !1;
  [g, m] = jn(() => (
    /** @type {V} */
    e[t]
  )), g === void 0 && s !== void 0 && (g = l(), c && (n && rn(), c(g)));
  var _;
  if (n ? _ = () => {
    var p = (
      /** @type {V} */
      e[t]
    );
    return p === void 0 ? l() : (o = !0, p);
  } : _ = () => {
    var p = (
      /** @type {V} */
      e[t]
    );
    return p !== void 0 && (i = /** @type {V} */
    void 0), p === void 0 ? i : p;
  }, n && (r & Ls) === 0)
    return _;
  if (c) {
    var u = e.$$legacy;
    return (
      /** @type {() => V} */
      (function(p, b) {
        return arguments.length > 0 ? ((!n || !b || u || m) && c(b ? _() : p), p) : _();
      })
    );
  }
  var C = !1, k = /* @__PURE__ */ qt(() => (C = !1, _()));
  f(k);
  var I = (
    /** @type {Effect} */
    A
  );
  return (
    /** @type {() => V} */
    (function(p, b) {
      if (arguments.length > 0) {
        const F = b ? f(k) : n && a ? Ve(p) : p;
        return be(k, F), C = !0, i !== void 0 && (i = F), p;
      }
      return qe && C || (I.f & Ne) !== 0 ? k.v : f(k);
    })
  );
}
var $n = /* @__PURE__ */ T('<section class="strongholds-mgmt-app svelte-po06u7"><h1> </h1> <p>Manage strongholds (GM only).</p></section>');
function Kn(e, t) {
  let r = zn(t, "name", 8, "Strongholds Management");
  var s = $n(), n = d(s), a = d(n);
  q(() => O(a, r())), x(e, s);
}
class Jr extends Application {
  constructor() {
    super(...arguments), this.component = null;
  }
  static get defaultOptions() {
    return {
      ...super.defaultOptions,
      template: "modules/strongholds-and-followers/templates/svelte-app.html",
      popOut: !0,
      width: 600,
      height: 400
    };
  }
  render(t, r) {
    const s = super.render(t, r), n = document.getElementById(this.options.id), a = this.options.svelte;
    return n && !this.component && a && (this.component = new a({ target: n })), s;
  }
}
const Ue = {
  settings: () => globalThis.game?.settings,
  user: () => globalThis.game?.user,
  system: () => globalThis.game?.system
}, me = class me {
  static getTypeDescription(t) {
    return this.STRONGHOLD_TYPE_DESCRIPTIONS[t] ?? "";
  }
  static getTypeMechanicsSummary(t) {
    return this.TYPE_MECHANICS_SUMMARY[t] ?? { demesne: [], actions: [], notes: [] };
  }
  static getClassMechanicsSummary(t) {
    return this.CLASS_MECHANICS_SUMMARY[t] ?? { followers: "", actions: [], tables: [] };
  }
  static getClassFlavorDescription(t) {
    return t ? this.CLASS_FLAVOR_DESCRIPTIONS[t] ?? "" : "";
  }
  static getCostConfig() {
    const t = this.STRONGHOLD_COSTS, r = Ue.settings()?.get("strongholds-and-followers", "buildingCosts") ?? {}, s = Ue.settings()?.get("strongholds-and-followers", "upgradeCosts") ?? {};
    return {
      building: { ...t.building, ...r },
      upgrading: { ...t.upgrading, ...s }
    };
  }
  static createStronghold(t, r, s = null, n = 1, a = "") {
    const i = this.getBuildingCost(r), o = (c) => Math.max(1, Math.min(5, Math.floor(c)));
    return {
      id: globalThis.foundry?.utils?.randomID?.() ?? crypto.randomUUID?.() ?? `${Date.now()}`,
      name: t,
      type: r,
      classFlavor: s,
      level: o(n),
      description: a,
      active: !0,
      createdBy: Ue.user()?.id ?? "unknown",
      createdDate: (/* @__PURE__ */ new Date()).toISOString(),
      buildingCost: i,
      totalCostPaid: i,
      bonuses: []
    };
  }
  static getBuildingCost(t) {
    return this.getCostConfig().building[t] ?? 0;
  }
  static getUpgradeCost(t, r) {
    const s = this.getCostConfig();
    let n = 0;
    for (let a = Math.max(2, t + 1); a <= Math.max(2, r); a++) {
      const i = Math.max(2, Math.min(5, a));
      n += s.upgrading[i] ?? 0;
    }
    return n;
  }
  static getTotalCostForLevel(t, r) {
    return this.getBuildingCost(t) + this.getUpgradeCost(1, r);
  }
  static addBonus(t, r, s) {
    const n = t[r];
    if (!n) return t;
    const i = { id: globalThis.foundry?.utils?.randomID?.() ?? crypto.randomUUID?.() ?? `${Date.now()}`, addedDate: (/* @__PURE__ */ new Date()).toISOString(), ...s };
    return n.bonuses = [...n.bonuses ?? [], i], { ...t, [r]: { ...n } };
  }
  static removeBonus(t, r, s) {
    const n = t[r];
    return n ? (n.bonuses = (n.bonuses ?? []).filter((a) => a.id !== s), { ...t, [r]: { ...n } }) : t;
  }
  static getCharacterName(t) {
    return t?.name ?? "Unknown Character";
  }
  static getCharacterLevel(t) {
    return t ? Ue.system()?.id === "dnd5e" ? t.system?.details?.level ?? 1 : t.system?.level ?? t.system?.details?.level ?? 1 : 1;
  }
  static getCharacterClasses(t) {
    if (!t) return [];
    if (Ue.system()?.id === "dnd5e") return Object.keys(t.classes ?? {});
    const r = t.system?.details?.class;
    return r ? [String(r)] : [];
  }
  static actorHasMatchingClass(t, r) {
    if (!t || !r) return !1;
    if (Ue.system()?.id === "dnd5e") {
      const i = t.classes ?? {};
      return Object.keys(i).some((o) => o.toLowerCase() === r.toLowerCase());
    }
    const s = t.type?.toLowerCase?.() ?? "", n = t.system?.details?.class?.toLowerCase?.() ?? "", a = r.toLowerCase();
    return s === a || n === a;
  }
  static getApplicableBonuses(t, r) {
    return r ? (t.bonuses ?? []).filter((n) => n.partyWide || !!t.classFlavor && this.actorHasMatchingClass(r, t.classFlavor) || !n.partyWide && !t.classFlavor) : [];
  }
};
me.STRONGHOLD_TYPES = [
  "temple",
  "keep",
  "tower",
  "establishment"
], me.STRONGHOLD_COSTS = {
  building: { temple: 25e3, keep: 5e4, tower: 25e3, establishment: 1e4 },
  upgrading: { 2: 1e4, 3: 25e3, 4: 5e4, 5: 1e5 }
}, me.STRONGHOLD_TYPE_DESCRIPTIONS = {
  keep: "A fortified residence for martial leadership. Emphasizes training drills, watch rotations, and attracts veteran retainers.",
  temple: "A sacred site of worship and healing. Offers rites, blessings, sanctuary, and faithful acolytes.",
  tower: "A seat of arcane study and experimentation. Enables research, spell scribing, wards, and curious constructs.",
  establishment: "A hub of commerce and influence. Generates income, rumors, contacts, and favors from patrons."
}, me.TYPE_MECHANICS_SUMMARY = {
  keep: {
    demesne: [
      "Improved security and morale throughout the demesne; garrison presence discourages threats.",
      "Rapid mustering and supply for defenders during crises.",
      "Increases readiness of allied units stationed nearby."
    ],
    actions: [
      "Drill Troops: Conduct training to improve a unit’s effectiveness for upcoming conflicts.",
      "Fortify Works: Improve defenses, repair breaches, or raise temporary works before a siege.",
      "Patrol & Recon: Send scouts to reveal threats, routes, or enemy dispositions.",
      "Rally Militia: Call on local levies to temporarily bolster forces."
    ],
    notes: ["Suited to martial characters and warfare-oriented campaigns."]
  },
  temple: {
    demesne: [
      "Sanctuary and healing for allies; rites uplift the faithful.",
      "Consecrated ground deters profane threats and unrest.",
      "Divine authority improves goodwill among locals and pilgrims."
    ],
    actions: [
      "Conduct Rites: Bestow blessings or omens on characters or units.",
      "Consecrate/Exorcise: Purify sites, remove blights, or repel malign influences.",
      "Petition the Faith: Leverage church networks for aid, supplies, or influence."
    ],
    notes: ["Thematic fit for divine casters and holy orders."]
  },
  tower: {
    demesne: [
      "Hub of research and experimentation; apprentices, labs, and wards.",
      "Arcane protections safeguard the environs from magical threats.",
      "Access to esoteric materials and assistants for projects."
    ],
    actions: [
      "Research & Scribing: Reduce time or cost to learn, scribe, or refine spells/rituals.",
      "Craft Arcana: Prepare scrolls, potions, or minor devices with improved reliability.",
      "Raise Wards: Establish temporary or situational magical defenses."
    ],
    notes: ["Ideal for arcane casters and scholarly pursuits."]
  },
  establishment: {
    demesne: [
      "Generates income and connections through trade, events, and patronage.",
      "Network of informants surfaces rumors, jobs, and social leverage.",
      "Boosts prosperity and goodwill, improving local cooperation."
    ],
    actions: [
      "Call in Favors: Convert goodwill into aid, introductions, or material support.",
      "Host Events: Raise renown, attract patrons, or calm tensions among factions.",
      "Broker Deals: Improve terms for procurement, contracts, or alliances."
    ],
    notes: ["Great for face characters, intrigue, and resource play."]
  }
}, me.CLASS_FLAVOR_DISPLAY = {
  barbarian: "Barbarian’s Camp",
  bard: "Bard’s Theater",
  cleric: "Cleric’s Church",
  druid: "Druid’s Grove",
  fighter: "Fighter’s Fortress",
  monk: "Monk’s Monastery",
  paladin: "Paladin’s Chapel",
  ranger: "Ranger’s Lodge",
  rogue: "Rogue’s Tavern",
  sorcerer: "Sorcerer’s Sanctum",
  warlock: "Warlock’s Fane",
  wizard: "Wizard’s Library"
}, me.CLASS_FLAVOR_DESCRIPTIONS = {
  barbarian: "A rugged camp of warbands where trials, feasts, and raids are mustered.",
  bard: "A lively theater that stages performances, spreads renown, and sways local opinion.",
  cleric: "A holy church that offers rites, healing, and guidance to the faithful.",
  druid: "A sacred grove tended by circles, where nature spirits are invoked and seasons observed.",
  fighter: "A disciplined fortress with drill yards, armories, and veteran captains.",
  monk: "A quiet monastery devoted to austerity, training, and contemplative practice.",
  paladin: "A consecrated chapel that upholds oaths, hosts vigils, and shelters the weak.",
  ranger: "A secluded lodge for scouts and trackers, mapping trails and warding borders.",
  rogue: "A bustling tavern that trades in secrets, safehouses, and shady opportunities.",
  sorcerer: "A personal sanctum attuned to bloodline magic, experiments, and unpredictable power.",
  warlock: "A veiled fane where pacts are honored, boons bargained, and signs interpreted.",
  wizard: "A vast library for research, scribing, and the careful study of the arcane."
}, me.CLASS_MECHANICS_SUMMARY = {
  barbarian: { followers: "Fierce retainers, skirmishers, and hardy scouts gravitate to your banner.", actions: ["Rally Warband: Stir warriors to a ferocious surge or swift pursuit.", "Trial of Mettle: Prove strength to gain the tribe’s support or intimidate rivals."], tables: ["Servitors (barbarian-themed allies and retainers)"] },
  bard: { followers: "Artists, heralds, and rumor-mongers expand your fame and influence.", actions: ["Command Performance: Inspire allies or sway the crowd’s mood decisively.", "Compose & Publicize: Convert renown into tangible favors over downtime."], tables: ["Servitors (performers, agents, and influential patrons)"] },
  cleric: { followers: "Acolytes, healers, and faithful lay clergy gather to serve.", actions: ["Divine Rites: Bless allies, sanctify ground, or oppose profane forces.", "Intercession: Seek signs or aid from your deity’s hierarchy."], tables: ["Divine Intervention (structured results and omens)"] },
  druid: { followers: "Wardens, herbalists, and beasts attend your circle’s call.", actions: ["Commune with Land: Learn of threats, resources, and seasonal shifts.", "Rally Wardens: Enlist beasts or circles to guard and guide."], tables: ["Servitors (natural allies and circles)"] },
  fighter: { followers: "Veteran soldiers, drill sergeants, and siege crews bolster your command.", actions: ["Drill & Discipline: Improve a unit’s readiness or cohesion before battle.", "Siege Readiness: Expedite fortification, engines, or supply lines."], tables: ["Servitors (martial units, engineers, captains)"] },
  monk: { followers: "Ascetics and martial adepts practice and teach under your guidance.", actions: ["Meditative Regimen: Restore focus; sharpen reflexes among adepts.", "Way of the Cloister: Intercede to resolve conflicts peaceably."], tables: ["Servitors (monastic adepts and allies)"] },
  paladin: { followers: "Squires, knights, and faithful retainers heed your oath.", actions: ["Oathbound Vigil: Inspire zeal, protect the weak, or bolster resolve.", "Sacred Muster: Call on allied orders for aid."], tables: ["Special Mounts (sacred or exemplar steeds)"] },
  ranger: { followers: "Trackers, scouts, and wardens secure the borders and wilds.", actions: ["Map & Harry: Chart safe routes, harry foes, or secure supply lines.", "Call of the Wilds: Enlist beasts or locals as guides and guards."], tables: ["Servitors (scouts, beasts, and wayfinders)"] },
  rogue: { followers: "Fixers, fences, and informants cultivate networks and opportunities.", actions: ["Pull Strings: Acquire illicit access, safehouses, or hush favors.", "Cover of Night: Arrange distractions, smuggling, or quiet exits."], tables: ["Servitors (contacts, crews, and cutpurses)"] },
  sorcerer: { followers: "Apprentices and attuned allies assist with volatile workings.", actions: ["Channel Lineage: Amplify a signature effect in a controlled setting.", "Sanctum Focus: Convert downtime into refined, reliable power."], tables: ["Servitors (bloodline-touched aids)"] },
  warlock: { followers: "Occultists and pact-sworn attendants manage signs and boons.", actions: ["Pact Observance: Seek counsel, omens, or temporary boons within bounds.", "Veil & Ward: Mask activities or bind an intrusion briefly."], tables: ["Servitors (cabalists and pact agents)"] },
  wizard: { followers: "Apprentices, scribes, and constructs sustain methodical study.", actions: ["Scriptorium: Compress time and cost to copy or prepare spellwork.", "Laboratory: Execute careful experiments with mitigated risk."], tables: ["Spell Customization (schools, materials, side-effects)"] }
};
let Q = me;
var Xn = /* @__PURE__ */ T('<button class="reload-clients" aria-label="Reload all clients" title="Reload all connected clients"><i class="fas fa-bolt" aria-hidden="true"></i></button>'), Zn = /* @__PURE__ */ T("<p><strong>Classes:</strong> </p>"), Jn = /* @__PURE__ */ T("<p><em>Showing D&D 5e stronghold bonuses applicable during extended rests</em></p>"), Qn = /* @__PURE__ */ T("<p><em> </em></p>"), ea = /* @__PURE__ */ T('<span class="stronghold-class svelte-1kntig0"> </span>'), ta = /* @__PURE__ */ T('<tr class="row-note svelte-1kntig0"><td colspan="6" class="cell-note svelte-1kntig0"> </td></tr>'), ra = /* @__PURE__ */ T('<tr class="row-note svelte-1kntig0"><td colspan="6" class="cell-note svelte-1kntig0"><em> </em></td></tr>'), sa = /* @__PURE__ */ T('<p class="class-flavor-text"> </p>'), na = /* @__PURE__ */ T('<div class="class-flavor-summary svelte-1kntig0"><span class="class-flavor-badge" title="Class Flavor"><i class="fas fa-hat-wizard"></i> </span> <!></div>'), aa = /* @__PURE__ */ T('<span class="action-chip svelte-1kntig0" title="Stronghold action"> </span>'), ia = /* @__PURE__ */ T('<div class="action-preview svelte-1kntig0"></div>'), la = /* @__PURE__ */ T("— <em> </em>", 1), oa = /* @__PURE__ */ T('<p class="class-bonus-note svelte-1kntig0"><i class="fas fa-star"></i> Includes class-flavored stronghold <!></p>'), ca = /* @__PURE__ */ T("<p><strong> </strong></p> <!>", 1), ua = /* @__PURE__ */ T('<p class="no-bonuses svelte-1kntig0">No custom bonuses have been added yet</p>'), fa = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><td colspan="2" class="svelte-1kntig0"> </td></tr>'), va = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><td colspan="2" class="svelte-1kntig0"> </td></tr>'), da = /* @__PURE__ */ T('<div class="mechanics-block type-summary"><table class="sg-table sg-table--compact sg-table--striped svelte-1kntig0"><thead><tr class="svelte-1kntig0"><th colspan="2" class="svelte-1kntig0"><i class="fas fa-globe"></i> Demesne Effects</th></tr></thead><tbody class="svelte-1kntig0"><!><tr class="svelte-1kntig0"><th colspan="2" class="svelte-1kntig0"><i class="fas fa-fist-raised"></i> Stronghold Actions</th></tr><!></tbody></table></div>'), pa = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><th style="width: 180px" class="svelte-1kntig0"><i class="fas fa-user-friends"></i> Followers</th><td class="svelte-1kntig0"> </td></tr>'), ha = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><td colspan="2" class="svelte-1kntig0"> </td></tr>'), _a = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><th colspan="2" class="svelte-1kntig0"><i class="fas fa-bolt"></i> Class Actions</th></tr> <!>', 1), ga = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><td colspan="2" class="svelte-1kntig0"> </td></tr>'), ma = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><th colspan="2" class="svelte-1kntig0"><i class="fas fa-table"></i> Tables</th></tr> <!>', 1), ba = /* @__PURE__ */ T('<div class="mechanics-block class-summary"><table class="sg-table sg-table--compact sg-table--striped svelte-1kntig0"><tbody class="svelte-1kntig0"><!><!><!></tbody></table></div>'), ya = /* @__PURE__ */ T('<span class="party-bonus"><i class="fas fa-users"></i> Party-wide</span>'), wa = /* @__PURE__ */ T('<span class="class-bonus"><i class="fas fa-user"></i> Character-specific</span>'), ka = /* @__PURE__ */ T('<tr class="svelte-1kntig0"><td class="svelte-1kntig0"><strong> </strong><div class="cell-note svelte-1kntig0"> </div></td><td class="svelte-1kntig0"><!></td></tr>'), Sa = /* @__PURE__ */ T('<table class="sg-table sg-table--compact sg-table--striped svelte-1kntig0"><thead><tr class="svelte-1kntig0"><th class="svelte-1kntig0">Bonus</th><th class="svelte-1kntig0">Type</th></tr></thead><tbody class="svelte-1kntig0"></tbody></table>'), Ca = /* @__PURE__ */ T('<p class="no-custom-bonuses">No custom bonuses have been added by the GM yet.</p>'), Ea = /* @__PURE__ */ T('<div><div class="stronghold-header"><div class="stronghold-title svelte-1kntig0"><h3> </h3> <div class="stronghold-meta svelte-1kntig0"><span class="stronghold-type svelte-1kntig0"> </span> <!> <span class="stronghold-level svelte-1kntig0"> </span></div></div> <button class="bonus-toggle svelte-1kntig0" aria-label="Toggle details" title="Show details"><i class="fas fa-chevron-down"></i></button></div> <div class="stronghold-summary"><table class="sg-table sg-table--compact sg-table--striped svelte-1kntig0"><thead><tr class="svelte-1kntig0"><th class="svelte-1kntig0"><i class="fas fa-chess-rook"></i> Type</th><th class="svelte-1kntig0"><i class="fas fa-hat-wizard"></i> Class</th><th class="svelte-1kntig0"><i class="fas fa-signal"></i> Level</th><th class="svelte-1kntig0"><i class="fas fa-user-friends"></i> Followers</th><th class="svelte-1kntig0"><i class="fas fa-coins"></i> Total Value</th><th class="svelte-1kntig0"><i class="fas fa-toggle-on"></i> Active</th></tr></thead><tbody class="svelte-1kntig0"><tr class="svelte-1kntig0"><td class="svelte-1kntig0"> </td><td class="svelte-1kntig0"> </td><td class="cell-num svelte-1kntig0"> </td><td class="svelte-1kntig0"> </td><td class="cell-num svelte-1kntig0"> </td><td class="cell-num svelte-1kntig0"><i class="fas fa-check-circle" title="Active"></i></td></tr><!><!></tbody></table> <!> <!></div> <div class="bonus-summary"><!></div> <div class="bonus-details svelte-1kntig0" style="display: none;"><div class="collapsible"><button class="section-toggle" type="button"><i class="fas fa-chevron-right"></i> Mechanics</button> <div class="section-body" style="display: none;"><!> <!></div></div> <div class="collapsible"><button class="section-toggle" type="button"><i class="fas fa-chevron-right"></i> Custom Bonuses</button> <div class="section-body" style="display: none;"><!></div></div></div></div>'), xa = /* @__PURE__ */ T('<div class="character-info svelte-1kntig0"><p><strong>Character:</strong> </p> <!> <!></div> <div class="strongholds-list"></div> <div class="extended-rest-info"><div class="info-box"><h4><i class="fas fa-bed"></i> Extended Rest Bonuses</h4> <p>These bonuses are applied automatically when you complete an extended rest (if auto-apply is enabled).</p> <p><strong>Party-wide bonuses</strong> apply to all characters, while <strong>class-specific bonuses</strong> only apply to matching classes.</p></div></div>', 1), Aa = /* @__PURE__ */ T(`<div class="no-strongholds svelte-1kntig0"><div class="empty-state"><i class="fas fa-castle fa-3x"></i> <h3>No Active Strongholds</h3> <p>Your party doesn't have any active strongholds yet.</p> <p>Ask your GM to create and activate strongholds to gain bonuses during extended rests.</p></div></div>`), Ta = /* @__PURE__ */ T('<section class="stronghold-viewer svelte-1kntig0"><div class="viewer-header svelte-1kntig0"><h2><i class="fas fa-castle"></i> Party Strongholds</h2> <div class="header-actions"><!> <button class="refresh-bonuses" aria-label="Refresh" title="Refresh stronghold data"><i class="fas fa-sync-alt" aria-hidden="true"></i></button></div></div> <!></section>');
function Ma(e, t) {
  cn(t, !1);
  let r = /* @__PURE__ */ Fr({
    strongholds: [],
    hasStrongholds: !1,
    characterName: "",
    characterClasses: [],
    characterLevel: 1,
    systemId: "unknown",
    isGM: !1
  });
  function s() {
    return globalThis.game;
  }
  function n() {
    return globalThis.ui;
  }
  async function a() {
    const p = s(), b = p.settings.get("strongholds-and-followers", "strongholds") ?? {}, F = Object.values(b).filter((P) => P.active), E = p.user?.character ?? null, S = E ? Q.getCharacterClasses(E) : [], R = E ? Q.getCharacterLevel(E) : 1, te = F.map((P) => {
      const ke = P.bonuses ?? [], Se = E ? Q.getApplicableBonuses(P, E) : ke.filter((He) => He.partyWide), re = Q.getTypeMechanicsSummary(P.type), U = P.classFlavor ? Q.getClassMechanicsSummary(P.classFlavor) : { followers: "", actions: [], tables: [] }, h = (P.level || 1) < 5, j = h ? Q.getUpgradeCost(P.level, P.level + 1) : 0, ae = [
        ...re?.actions ?? [],
        ...U?.actions ?? []
      ].filter(Boolean).slice(0, 3);
      return {
        ...P,
        customBonuses: ke,
        myBonuses: Se,
        typeDescription: Q.getTypeDescription(P.type),
        typeSummary: re,
        classSummary: U,
        classFlavorDisplay: P.classFlavor ? Q.CLASS_FLAVOR_DISPLAY[P.classFlavor] ?? P.classFlavor : null,
        hasClassBonuses: !!(P.classFlavor && Q.actorHasMatchingClass(E, P.classFlavor)),
        canUpgrade: h,
        upgradeCost: j,
        actionPreview: ae
      };
    });
    be(r, {
      strongholds: te,
      hasStrongholds: F.length > 0,
      characterName: Q.getCharacterName(E),
      characterClasses: S,
      characterLevel: R,
      systemId: String(p.system?.id ?? "unknown"),
      isGM: !!p.user?.isGM
    });
  }
  function i() {
    const p = s(), b = n();
    if (!p.user?.isGM) return b?.notifications?.warn?.("Only the GM can reload clients");
    try {
      p.socket?.emit?.("module.strongholds-and-followers", { action: "reload" }), b?.notifications?.info?.("Requested reload for all connected clients...");
    } catch (F) {
      console.error("Strongholds | Failed to emit reload", F), b?.notifications?.error?.("Failed to request reload");
    }
  }
  function o(p) {
    const b = p.currentTarget, E = b?.closest(".stronghold-item")?.querySelector(".bonus-details"), S = b?.querySelector("i");
    if (!E || !S) return;
    E.style.display !== "none" && E.style.display !== "" ? (E.style.display = "none", S.className = "fas fa-chevron-down") : (E.style.display = "block", S.className = "fas fa-chevron-up");
  }
  function l(p) {
    const b = p.currentTarget, F = b?.nextElementSibling, E = b?.querySelector("i");
    if (!F || !E) return;
    const S = F.style.display === "none" || !F.style.display;
    F.style.display = S ? "block" : "none", E.className = S ? "fas fa-chevron-down" : "fas fa-chevron-right";
  }
  qn(() => {
    a();
  }), Yn();
  var c = Ta(), v = d(c), g = w(d(v), 2), m = d(g);
  {
    var _ = (p) => {
      var b = Xn();
      Qe("click", b, et(i)), x(p, b);
    };
    N(m, (p) => {
      f(r).isGM && p(_);
    });
  }
  var u = w(m, 2), C = w(v, 2);
  {
    var k = (p) => {
      var b = xa(), F = Je(b), E = d(F), S = w(d(E)), R = w(E, 2);
      {
        var te = (U) => {
          var h = Zn(), j = w(d(h));
          q((ae) => O(j, ` ${ae ?? ""} (Level ${f(r).characterLevel ?? ""})`), [() => f(r).characterClasses.join(", ")]), x(U, h);
        };
        N(R, (U) => {
          f(r).characterClasses.length && U(te);
        });
      }
      var P = w(R, 2);
      {
        var ke = (U) => {
          var h = Jn();
          x(U, h);
        }, Se = (U) => {
          var h = Qn(), j = d(h), ae = d(j);
          q(() => O(ae, `System: ${f(r).systemId ?? ""} - Some features may require D&D 5e system`)), x(U, h);
        };
        N(P, (U) => {
          f(r).systemId === "dnd5e" ? U(ke) : U(Se, !1);
        });
      }
      var re = w(F, 2);
      Fe(re, 5, () => f(r).strongholds, De, (U, h) => {
        var j = Ea(), ae = d(j), He = d(ae), lt = d(He), Qr = d(lt), es = w(lt, 2), jt = d(es), ts = d(jt), zt = w(jt, 2);
        {
          var rs = (y) => {
            var D = ea(), L = d(D);
            q(() => O(L, f(h).classFlavorDisplay ?? f(h).classFlavor)), x(y, D);
          };
          N(zt, (y) => {
            f(h).classFlavor && y(rs);
          });
        }
        var ss = w(zt, 2), ns = d(ss), as = w(He, 2), $t = w(ae, 2), Kt = d($t), is = w(d(Kt)), Xt = d(is), Zt = d(Xt), ls = d(Zt), Jt = w(Zt), os = d(Jt), Qt = w(Jt), cs = d(Qt), er = w(Qt), us = d(er), fs = w(er), vs = d(fs), tr = w(Xt);
        {
          var ds = (y) => {
            var D = ta(), L = d(D), z = d(L);
            q(() => O(z, f(h).description)), x(y, D);
          };
          N(tr, (y) => {
            f(h).description && y(ds);
          });
        }
        var ps = w(tr);
        {
          var hs = (y) => {
            var D = ra(), L = d(D), z = d(L), V = d(z);
            q(() => O(V, f(h).typeDescription)), x(y, D);
          };
          N(ps, (y) => {
            f(h).typeDescription && y(hs);
          });
        }
        var rr = w(Kt, 2);
        {
          var _s = (y) => {
            var D = na(), L = d(D), z = w(d(L)), V = w(L, 2);
            {
              var ie = ($) => {
                var K = sa(), Z = d(K);
                q((fe) => O(Z, fe), [
                  () => Q.getClassFlavorDescription(f(h).classFlavor)
                ]), x($, K);
              };
              N(V, ($) => {
                Q.getClassFlavorDescription(f(h).classFlavor) && $(ie);
              });
            }
            q(() => O(z, ` ${f(h).classFlavorDisplay ?? ""}`)), x(y, D);
          };
          N(rr, (y) => {
            f(h).classFlavorDisplay && y(_s);
          });
        }
        var gs = w(rr, 2);
        {
          var ms = (y) => {
            var D = ia();
            Fe(D, 5, () => f(h).actionPreview, De, (L, z) => {
              var V = aa(), ie = d(V);
              q(() => O(ie, f(z))), x(L, V);
            }), x(y, D);
          };
          N(gs, (y) => {
            f(h).actionPreview?.length && y(ms);
          });
        }
        var sr = w($t, 2), bs = d(sr);
        {
          var ys = (y) => {
            var D = ca(), L = Je(D), z = d(L), V = d(z), ie = w(L, 2);
            {
              var $ = (K) => {
                var Z = oa(), fe = w(d(Z), 2);
                {
                  var B = (J) => {
                    var de = la(), ge = w(Je(de)), Me = d(ge);
                    q(() => O(Me, f(h).classFlavorDisplay)), x(J, de);
                  };
                  N(fe, (J) => {
                    f(h).classFlavorDisplay && J(B);
                  });
                }
                x(K, Z);
              };
              N(ie, (K) => {
                f(h).hasClassBonuses && K($);
              });
            }
            q(() => O(V, `${f(h).customBonuses.length ?? ""} custom bonus${f(h).customBonuses.length === 1 ? "" : "es"} available`)), x(y, D);
          }, ws = (y) => {
            var D = ua();
            x(y, D);
          };
          N(bs, (y) => {
            f(h).customBonuses?.length ? y(ys) : y(ws, !1);
          });
        }
        var ks = w(sr, 2), nr = d(ks), ar = d(nr), Ss = w(ar, 2), ir = d(Ss);
        {
          var Cs = (y) => {
            var D = da(), L = d(D), z = w(d(L)), V = d(z);
            Fe(V, 1, () => f(h).typeSummary.demesne, De, ($, K) => {
              var Z = fa(), fe = d(Z), B = d(fe);
              q(() => O(B, f(K))), x($, Z);
            });
            var ie = w(V, 2);
            Fe(ie, 1, () => f(h).typeSummary.actions, De, ($, K) => {
              var Z = va(), fe = d(Z), B = d(fe);
              q(() => O(B, f(K))), x($, Z);
            }), x(y, D);
          };
          N(ir, (y) => {
            f(h).typeSummary && y(Cs);
          });
        }
        var Es = w(ir, 2);
        {
          var xs = (y) => {
            var D = ba(), L = d(D), z = d(L), V = d(z);
            {
              var ie = (B) => {
                var J = pa(), de = w(d(J)), ge = d(de);
                q(() => O(ge, f(h).classSummary.followers)), x(B, J);
              };
              N(V, (B) => {
                f(h).classSummary.followers && B(ie);
              });
            }
            var $ = w(V);
            {
              var K = (B) => {
                var J = _a(), de = w(Je(J), 2);
                Fe(de, 1, () => f(h).classSummary.actions, De, (ge, Me) => {
                  var le = ha(), Re = d(le), wt = d(Re);
                  q(() => O(wt, f(Me))), x(ge, le);
                }), x(B, J);
              };
              N($, (B) => {
                f(h).classSummary.actions?.length && B(K);
              });
            }
            var Z = w($);
            {
              var fe = (B) => {
                var J = ma(), de = w(Je(J), 2);
                Fe(de, 1, () => f(h).classSummary.tables, De, (ge, Me) => {
                  var le = ga(), Re = d(le), wt = d(Re);
                  q(() => O(wt, f(Me))), x(ge, le);
                }), x(B, J);
              };
              N(Z, (B) => {
                f(h).classSummary.tables?.length && B(fe);
              });
            }
            x(y, D);
          };
          N(Es, (y) => {
            f(h).classSummary && y(xs);
          });
        }
        var As = w(nr, 2), lr = d(As), Ts = w(lr, 2), Ms = d(Ts);
        {
          var Rs = (y) => {
            var D = Sa(), L = w(d(D));
            Fe(L, 5, () => f(h).customBonuses, De, (z, V) => {
              var ie = ka(), $ = d(ie), K = d($), Z = d(K), fe = w(K), B = d(fe), J = w($), de = d(J);
              {
                var ge = (le) => {
                  var Re = ya();
                  x(le, Re);
                }, Me = (le) => {
                  var Re = wa();
                  x(le, Re);
                };
                N(de, (le) => {
                  f(V).partyWide ? le(ge) : le(Me, !1);
                });
              }
              q(() => {
                O(Z, f(V).name), O(B, f(V).description);
              }), x(z, ie);
            }), x(y, D);
          }, Ds = (y) => {
            var D = Ca();
            x(y, D);
          };
          N(Ms, (y) => {
            f(h).customBonuses?.length ? y(Rs) : y(Ds, !1);
          });
        }
        q(
          (y) => {
            Wn(j, 1, `stronghold-item type-${f(h).type ?? ""}`, "svelte-1kntig0"), O(Qr, f(h).name), O(ts, f(h).type), O(ns, `Level ${f(h).level ?? ""}`), O(ls, f(h).type), O(os, f(h).classFlavorDisplay ?? f(h).classFlavor ?? "—"), O(cs, `${f(h).level ?? ""} / 5`), O(us, f(h).classSummary.followers || "—"), O(vs, y);
          },
          [
            () => f(h).totalCostPaid ? f(h).totalCostPaid.toLocaleString() + " gp" : "—"
          ]
        ), Qe("click", as, et(o)), Qe("click", ar, et(l)), Qe("click", lr, et(l)), x(U, j);
      }), q(() => O(S, ` ${f(r).characterName ?? ""}`)), x(p, b);
    }, I = (p) => {
      var b = Aa();
      x(p, b);
    };
    N(C, (p) => {
      f(r).hasStrongholds ? p(k) : p(I, !1);
    });
  }
  Qe("click", u, et(a)), x(e, c), un();
}
class Ra extends Jr {
}
function Da() {
  const e = { id: "stronghold-viewer", title: "Party Strongholds", svelte: Ma };
  return new Ra(e).render(!0);
}
class Fa extends Jr {
}
Hooks.once("init", () => {
  console.log("Strongholds | init");
});
Hooks.once("ready", () => {
  console.log("Strongholds | ready");
});
Hooks.on("getSceneControlButtons", (e) => {
  console.log("Strongholds | getSceneControlButtons hook called");
  const t = game.user?.isGM;
  console.log("Strongholds | User is GM:", t);
  const r = (i) => {
    console.log("Strongholds | View tool invoked", i);
    try {
      const o = Da();
      return console.log("Strongholds | Viewer app created:", o), o;
    } catch (o) {
      console.error("Strongholds | Error opening viewer:", o), globalThis.ui?.notifications?.error?.("Failed to open Stronghold Viewer");
    }
  }, s = (i) => {
    console.log("Strongholds | Manage tool invoked", i);
    try {
      const o = new Fa({
        id: "strongholds-mgmt",
        title: "Strongholds Management",
        svelte: Kn
      }).render(!0);
      return console.log("Strongholds | Management app created:", o), o;
    } catch (o) {
      console.error("Strongholds | Error opening management:", o), globalThis.ui?.notifications?.error?.("Failed to open Strongholds Management");
    }
  }, n = [
    {
      name: "view",
      title: "View",
      icon: "fas fa-eye",
      button: !0,
      onClick: r,
      onChange: r
    },
    t ? {
      name: "manage",
      title: "Manage",
      icon: "fas fa-cog",
      button: !0,
      onClick: s,
      onChange: s
    } : null
  ].filter(Boolean), a = {
    name: "strongholds",
    title: "Strongholds",
    icon: "fas fa-home",
    layer: "tokens",
    tools: n
  };
  console.log("Strongholds | Adding control with tools:", n), e.push(a);
});
