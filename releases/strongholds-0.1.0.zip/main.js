typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
let be = !1, _t = !1;
function ht() {
  be = !0;
}
ht();
const dt = 2, pt = 4, gt = 8, wt = 2, w = Symbol(), qe = !1;
var mt = Array.isArray, yt = Array.prototype.indexOf, Pe = Object.defineProperty, ue = Object.getOwnPropertyDescriptor, Et = Object.prototype, bt = Array.prototype, St = Object.getPrototypeOf;
function xt() {
  var e, t, n = new Promise((r, s) => {
    e = r, t = s;
  });
  return { promise: n, resolve: e, reject: t };
}
const S = 2, Tt = 4, kt = 8, te = 16, ne = 32, z = 64, je = 128, k = 256, ae = 512, E = 1024, O = 2048, F = 4096, oe = 8192, Y = 16384, Le = 32768, Ce = 1 << 17, Ot = 1 << 18, Se = 1 << 19, me = 1 << 21, xe = 1 << 22, B = 1 << 23, fe = Symbol("$state"), Rt = Symbol("legacy props"), Te = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function At() {
  throw new Error("https://svelte.dev/e/await_outside_boundary");
}
function Pt() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Ct() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function Nt(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function It() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Mt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Dt() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Be(e) {
  return e === this.v;
}
function Ft(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function qt(e) {
  return !Ft(e, this.v);
}
let V = null;
function ce(e) {
  V = e;
}
function re() {
  return !be || V !== null && V.l === null;
}
const jt = /* @__PURE__ */ new WeakMap();
function Lt(e) {
  var t = _;
  if (t === null)
    return h.f |= B, e;
  if ((t.f & Le) === 0) {
    if ((t.f & je) === 0)
      throw !t.parent && e instanceof Error && Ue(e), e;
    t.b.error(e);
  } else
    ke(e, t);
}
function ke(e, t) {
  for (; t !== null; ) {
    if ((t.f & je) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e instanceof Error && Ue(e), e;
}
function Ue(e) {
  const t = jt.get(e);
  t && (Pe(e, "message", {
    value: t.message
  }), Pe(e, "stack", {
    value: t.stack
  }));
}
function Bt() {
  for (var e = (
    /** @type {Effect} */
    _.b
  ); e !== null && !e.has_pending_snippet(); )
    e = e.parent;
  return e === null && At(), e;
}
// @__NO_SIDE_EFFECTS__
function Ve(e) {
  var t = S | O, n = h !== null && (h.f & S) !== 0 ? (
    /** @type {Derived} */
    h
  ) : null;
  return _ === null || n !== null && (n.f & k) !== 0 ? t |= k : _.f |= Se, {
    ctx: V,
    deps: null,
    effects: null,
    equals: Be,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      w
    ),
    wv: 0,
    parent: n ?? _,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function Ut(e, t) {
  let n = (
    /** @type {Effect | null} */
    _
  );
  n === null && Pt();
  var r = (
    /** @type {Boundary} */
    n.b
  ), s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), l = We(
    /** @type {V} */
    w
  ), u = null, a = !h;
  return Qt(() => {
    try {
      var i = e();
    } catch (v) {
      i = Promise.reject(v);
    }
    var f = () => i;
    s = u?.then(f, f) ?? Promise.resolve(i), u = s;
    var o = (
      /** @type {Batch} */
      y
    ), c = r.pending;
    a && (r.update_pending_count(1), c || o.increment());
    const p = (v, d = void 0) => {
      u = null, c || o.activate(), d ? d !== Te && (l.f |= B, Ee(l, d)) : ((l.f & B) !== 0 && (l.f ^= B), Ee(l, v)), a && (r.update_pending_count(-1), c || o.decrement()), Ke();
    };
    if (s.then(p, (v) => p(null, v || "unknown")), o)
      return () => {
        queueMicrotask(() => o.neuter());
      };
  }), new Promise((i) => {
    function f(o) {
      function c() {
        o === s ? i(l) : f(s);
      }
      o.then(c, c);
    }
    f(s);
  });
}
// @__NO_SIDE_EFFECTS__
function Ye(e) {
  const t = /* @__PURE__ */ Ve(e);
  return t.equals = qt, t;
}
function He(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      pe(
        /** @type {Effect} */
        t[n]
      );
  }
}
function Vt(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & S) === 0)
      return (
        /** @type {Effect} */
        t
      );
    t = t.parent;
  }
  return null;
}
function Oe(e) {
  var t, n = _;
  W(Vt(e));
  try {
    He(e), t = it(e);
  } finally {
    W(n);
  }
  return t;
}
function Ge(e) {
  var t = Oe(e);
  if (e.equals(t) || (e.v = t, e.wv = lt()), !Z)
    if ($ !== null)
      $.set(e, e.v);
    else {
      var n = (N || (e.f & k) !== 0) && e.deps !== null ? F : E;
      T(e, n);
    }
}
function Yt(e, t, n) {
  const r = re() ? Ve : Ye;
  if (t.length === 0) {
    n(e.map(r));
    return;
  }
  var s = y, l = (
    /** @type {Effect} */
    _
  ), u = Ht(), a = Bt();
  Promise.all(t.map((i) => /* @__PURE__ */ Ut(i))).then((i) => {
    s?.activate(), u();
    try {
      n([...e.map(r), ...i]);
    } catch (f) {
      (l.f & Y) === 0 && ke(f, l);
    }
    s?.deactivate(), Ke();
  }).catch((i) => {
    a.error(i);
  });
}
function Ht() {
  var e = _, t = h, n = V;
  return function() {
    W(e), D(t), ce(n);
  };
}
function Ke() {
  W(null), D(null), ce(null);
}
const J = /* @__PURE__ */ new Set();
let y = null, $ = null, Ne = /* @__PURE__ */ new Set(), ve = [];
function $e() {
  const e = (
    /** @type {() => void} */
    ve.shift()
  );
  ve.length > 0 && queueMicrotask($e), e();
}
let Q = [], Re = null, ye = !1;
class X {
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  #l = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #s = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #e = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #a = null;
  /**
   * True if an async effect inside this batch resolved and
   * its parent branch was already deleted
   */
  #o = !1;
  /**
   * Async effects (created inside `async_derived`) encountered during processing.
   * These run after the rest of the batch has updated, since they should
   * always have the latest values
   * @type {Effect[]}
   */
  #n = [];
  /**
   * The same as `#async_effects`, but for effects inside a newly-created
   * `<svelte:boundary>` — these do not prevent the batch from committing
   * @type {Effect[]}
   */
  #i = [];
  /**
   * Template effects and `$effect.pre` effects, which run when
   * a batch is committed
   * @type {Effect[]}
   */
  #r = [];
  /**
   * The same as `#render_effects`, but for `$effect` (which runs after)
   * @type {Effect[]}
   */
  #t = [];
  /**
   * Block effects, which may need to re-run on subsequent flushes
   * in order to update internal sources (e.g. each block items)
   * @type {Effect[]}
   */
  #u = [];
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Effect[]}
   */
  #c = [];
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Effect[]}
   */
  #v = [];
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    Q = [];
    var n = null;
    if (J.size > 1) {
      n = /* @__PURE__ */ new Map(), $ = /* @__PURE__ */ new Map();
      for (const [l, u] of this.current)
        n.set(l, { v: l.v, wv: l.wv }), l.v = u;
      for (const l of J)
        if (l !== this)
          for (const [u, a] of l.#l)
            n.has(u) || (n.set(u, { v: u.v, wv: u.wv }), u.v = a);
    }
    for (const l of t)
      this.#h(l);
    if (this.#n.length === 0 && this.#e === 0) {
      this.#_();
      var r = this.#r, s = this.#t;
      this.#r = [], this.#t = [], this.#u = [], y = null, Ie(r), Ie(s), y === null ? y = this : J.delete(this), this.#a?.resolve();
    } else
      this.#f(this.#r), this.#f(this.#t), this.#f(this.#u);
    if (n) {
      for (const [l, { v: u, wv: a }] of n)
        l.wv <= a && (l.v = u);
      $ = null;
    }
    for (const l of this.#n)
      K(l);
    for (const l of this.#i)
      K(l);
    this.#n = [], this.#i = [];
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   */
  #h(t) {
    t.f ^= E;
    for (var n = t.first; n !== null; ) {
      var r = n.f, s = (r & (ne | z)) !== 0, l = s && (r & E) !== 0, u = l || (r & oe) !== 0 || this.skipped_effects.has(n);
      if (!u && n.fn !== null) {
        if (s)
          n.f ^= E;
        else if ((r & Tt) !== 0)
          this.#t.push(n);
        else if ((r & E) === 0)
          if ((r & xe) !== 0) {
            var a = n.b?.pending ? this.#i : this.#n;
            a.push(n);
          } else ge(n) && ((n.f & te) !== 0 && this.#u.push(n), K(n));
        var i = n.first;
        if (i !== null) {
          n = i;
          continue;
        }
      }
      var f = n.parent;
      for (n = n.next; n === null && f !== null; )
        n = f.next, f = f.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #f(t) {
    for (const n of t)
      ((n.f & O) !== 0 ? this.#c : this.#v).push(n), T(n, E);
    t.length = 0;
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    this.#l.has(t) || this.#l.set(t, n), this.current.set(t, t.v);
  }
  activate() {
    y = this;
  }
  deactivate() {
    y = null;
    for (const t of Ne)
      if (Ne.delete(t), t(), y !== null)
        break;
  }
  neuter() {
    this.#o = !0;
  }
  flush() {
    Q.length > 0 ? Gt() : this.#_(), y === this && (this.#e === 0 && J.delete(this), this.deactivate());
  }
  /**
   * Append and remove branches to/from the DOM
   */
  #_() {
    if (!this.#o)
      for (const t of this.#s)
        t();
    this.#s.clear();
  }
  increment() {
    this.#e += 1;
  }
  decrement() {
    if (this.#e -= 1, this.#e === 0) {
      for (const t of this.#c)
        T(t, O), _e(t);
      for (const t of this.#v)
        T(t, F), _e(t);
      this.#r = [], this.#t = [], this.flush();
    } else
      this.deactivate();
  }
  /** @param {() => void} fn */
  add_callback(t) {
    this.#s.add(t);
  }
  settled() {
    return (this.#a ??= xt()).promise;
  }
  static ensure() {
    if (y === null) {
      const t = y = new X();
      J.add(y), X.enqueue(() => {
        y === t && t.flush();
      });
    }
    return y;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    ve.length === 0 && queueMicrotask($e), ve.unshift(t);
  }
}
function Gt() {
  var e = G;
  ye = !0;
  try {
    var t = 0;
    for (Me(!0); Q.length > 0; ) {
      var n = X.ensure();
      if (t++ > 1e3) {
        var r, s;
        Kt();
      }
      n.process(Q), M.clear();
    }
  } finally {
    ye = !1, Me(e), Re = null;
  }
}
function Kt() {
  try {
    Ct();
  } catch (e) {
    ke(e, Re);
  }
}
let j = null;
function Ie(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & (Y | oe)) === 0 && ge(r) && (j = [], K(r), r.deps === null && r.first === null && r.nodes_start === null && (r.teardown === null && r.ac === null ? nt(r) : r.fn = null), j.length > 0)) {
        M.clear();
        for (const s of j)
          K(s);
        j = [];
      }
    }
    j = null;
  }
}
function _e(e) {
  for (var t = Re = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (ye && t === _ && (n & te) !== 0)
      return;
    if ((n & (z | ne)) !== 0) {
      if ((n & E) === 0) return;
      t.f ^= E;
    }
  }
  Q.push(t);
}
const M = /* @__PURE__ */ new Map();
function We(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: Be,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function P(e, t) {
  const n = We(e);
  return tn(n), n;
}
function C(e, t, n = !1) {
  h !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!L || (h.f & Ce) !== 0) && re() && (h.f & (S | te | xe | Ce)) !== 0 && !R?.includes(e) && Dt();
  let r = n ? H(t) : t;
  return Ee(e, r);
}
function Ee(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    Z ? M.set(e, t) : M.set(e, n), e.v = t;
    var r = X.ensure();
    r.capture(e, n), (e.f & S) !== 0 && ((e.f & O) !== 0 && Oe(
      /** @type {Derived} */
      e
    ), T(e, (e.f & k) === 0 ? E : F)), e.wv = lt(), ze(e, O), re() && _ !== null && (_.f & E) !== 0 && (_.f & (ne | z)) === 0 && (x === null ? nn([e]) : x.push(e));
  }
  return t;
}
function we(e) {
  C(e, e.v + 1);
}
function ze(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var r = re(), s = n.length, l = 0; l < s; l++) {
      var u = n[l], a = u.f;
      if (!(!r && u === _)) {
        var i = (a & O) === 0;
        i && T(u, t), (a & S) !== 0 ? ze(
          /** @type {Derived} */
          u,
          F
        ) : i && ((a & te) !== 0 && j !== null && j.push(
          /** @type {Effect} */
          u
        ), _e(
          /** @type {Effect} */
          u
        ));
      }
    }
}
function H(e) {
  if (typeof e != "object" || e === null || fe in e)
    return e;
  const t = St(e);
  if (t !== Et && t !== bt)
    return e;
  var n = /* @__PURE__ */ new Map(), r = mt(e), s = /* @__PURE__ */ P(0), l = U, u = (a) => {
    if (U === l)
      return a();
    var i = h, f = U;
    D(null), Fe(l);
    var o = a();
    return D(i), Fe(f), o;
  };
  return r && n.set("length", /* @__PURE__ */ P(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(a, i, f) {
        (!("value" in f) || f.configurable === !1 || f.enumerable === !1 || f.writable === !1) && It();
        var o = n.get(i);
        return o === void 0 ? o = u(() => {
          var c = /* @__PURE__ */ P(f.value);
          return n.set(i, c), c;
        }) : C(o, f.value, !0), !0;
      },
      deleteProperty(a, i) {
        var f = n.get(i);
        if (f === void 0) {
          if (i in a) {
            const o = u(() => /* @__PURE__ */ P(w));
            n.set(i, o), we(s);
          }
        } else
          C(f, w), we(s);
        return !0;
      },
      get(a, i, f) {
        if (i === fe)
          return e;
        var o = n.get(i), c = i in a;
        if (o === void 0 && (!c || ue(a, i)?.writable) && (o = u(() => {
          var v = H(c ? a[i] : w), d = /* @__PURE__ */ P(v);
          return d;
        }), n.set(i, o)), o !== void 0) {
          var p = I(o);
          return p === w ? void 0 : p;
        }
        return Reflect.get(a, i, f);
      },
      getOwnPropertyDescriptor(a, i) {
        var f = Reflect.getOwnPropertyDescriptor(a, i);
        if (f && "value" in f) {
          var o = n.get(i);
          o && (f.value = I(o));
        } else if (f === void 0) {
          var c = n.get(i), p = c?.v;
          if (c !== void 0 && p !== w)
            return {
              enumerable: !0,
              configurable: !0,
              value: p,
              writable: !0
            };
        }
        return f;
      },
      has(a, i) {
        if (i === fe)
          return !0;
        var f = n.get(i), o = f !== void 0 && f.v !== w || Reflect.has(a, i);
        if (f !== void 0 || _ !== null && (!o || ue(a, i)?.writable)) {
          f === void 0 && (f = u(() => {
            var p = o ? H(a[i]) : w, v = /* @__PURE__ */ P(p);
            return v;
          }), n.set(i, f));
          var c = I(f);
          if (c === w)
            return !1;
        }
        return o;
      },
      set(a, i, f, o) {
        var c = n.get(i), p = i in a;
        if (r && i === "length")
          for (var v = f; v < /** @type {Source<number>} */
          c.v; v += 1) {
            var d = n.get(v + "");
            d !== void 0 ? C(d, w) : v in a && (d = u(() => /* @__PURE__ */ P(w)), n.set(v + "", d));
          }
        if (c === void 0)
          (!p || ue(a, i)?.writable) && (c = u(() => /* @__PURE__ */ P(void 0)), C(c, H(f)), n.set(i, c));
        else {
          p = c.v !== w;
          var q = u(() => H(f));
          C(c, q);
        }
        var A = Reflect.getOwnPropertyDescriptor(a, i);
        if (A?.set && A.set.call(o, f), !p) {
          if (r && typeof i == "string") {
            var le = (
              /** @type {Source<number>} */
              n.get("length")
            ), g = Number(i);
            Number.isInteger(g) && g >= le.v && C(le, g + 1);
          }
          we(s);
        }
        return !0;
      },
      ownKeys(a) {
        I(s);
        var i = Reflect.ownKeys(a).filter((c) => {
          var p = n.get(c);
          return p === void 0 || p.v !== w;
        });
        for (var [f, o] of n)
          o.v !== w && !(f in a) && i.push(f);
        return i;
      },
      setPrototypeOf() {
        Mt();
      }
    }
  );
}
var $t, Wt, zt;
// @__NO_SIDE_EFFECTS__
function Ze(e) {
  return Wt.call(e);
}
// @__NO_SIDE_EFFECTS__
function Zt(e) {
  return zt.call(e);
}
function he(e, t) {
  return /* @__PURE__ */ Ze(e);
}
function Je(e) {
  var t = h, n = _;
  D(null), W(null);
  try {
    return e();
  } finally {
    D(t), W(n);
  }
}
function Jt(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function Qe(e, t, n, r = !0) {
  var s = _;
  s !== null && (s.f & oe) !== 0 && (e |= oe);
  var l = {
    ctx: V,
    deps: null,
    nodes_start: null,
    nodes_end: null,
    f: e | O,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: s,
    b: s && s.b,
    prev: null,
    teardown: null,
    transitions: null,
    wv: 0,
    ac: null
  };
  try {
    K(l), l.f |= Le;
  } catch (i) {
    throw pe(l), i;
  }
  var u = l.deps === null && l.first === null && l.nodes_start === null && l.teardown === null && (l.f & Se) === 0;
  if (!u && r && (s !== null && Jt(l, s), h !== null && (h.f & S) !== 0 && (e & z) === 0)) {
    var a = (
      /** @type {Derived} */
      h
    );
    (a.effects ??= []).push(l);
  }
  return l;
}
function Qt(e) {
  return Qe(xe | Se, e);
}
function Xe(e, t = [], n = []) {
  Yt(t, n, (r) => {
    Qe(kt, () => e(...r.map(I)), !0);
  });
}
function et(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = Z, r = h;
    De(!0), D(null);
    try {
      t.call(null);
    } finally {
      De(n), D(r);
    }
  }
}
function tt(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const s = n.ac;
    s !== null && Je(() => {
      s.abort(Te);
    });
    var r = n.next;
    (n.f & z) !== 0 ? n.parent = null : pe(n, t), n = r;
  }
}
function Xt(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & ne) === 0 && pe(t), t = n;
  }
}
function pe(e, t = !0) {
  var n = !1;
  (t || (e.f & Ot) !== 0) && e.nodes_start !== null && e.nodes_end !== null && (en(
    e.nodes_start,
    /** @type {TemplateNode} */
    e.nodes_end
  ), n = !0), tt(e, t && !n), de(e, 0), T(e, Y);
  var r = e.transitions;
  if (r !== null)
    for (const l of r)
      l.stop();
  et(e);
  var s = e.parent;
  s !== null && s.first !== null && nt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes_start = e.nodes_end = e.ac = null;
}
function en(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : (
      /** @type {TemplateNode} */
      /* @__PURE__ */ Zt(e)
    );
    e.remove(), e = n;
  }
}
function nt(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
let G = !1;
function Me(e) {
  G = e;
}
let Z = !1;
function De(e) {
  Z = e;
}
let h = null, L = !1;
function D(e) {
  h = e;
}
let _ = null;
function W(e) {
  _ = e;
}
let R = null;
function tn(e) {
  h !== null && (R === null ? R = [e] : R.push(e));
}
let m = null, b = 0, x = null;
function nn(e) {
  x = e;
}
let rt = 1, ee = 0, U = ee;
function Fe(e) {
  U = e;
}
let N = !1;
function lt() {
  return ++rt;
}
function ge(e) {
  var t = e.f;
  if ((t & O) !== 0)
    return !0;
  if ((t & F) !== 0) {
    var n = e.deps, r = (t & k) !== 0;
    if (n !== null) {
      var s, l, u = (t & ae) !== 0, a = r && _ !== null && !N, i = n.length;
      if ((u || a) && (_ === null || (_.f & Y) === 0)) {
        var f = (
          /** @type {Derived} */
          e
        ), o = f.parent;
        for (s = 0; s < i; s++)
          l = n[s], (u || !l?.reactions?.includes(f)) && (l.reactions ??= []).push(f);
        u && (f.f ^= ae), a && o !== null && (o.f & k) === 0 && (f.f ^= k);
      }
      for (s = 0; s < i; s++)
        if (l = n[s], ge(
          /** @type {Derived} */
          l
        ) && Ge(
          /** @type {Derived} */
          l
        ), l.wv > e.wv)
          return !0;
    }
    (!r || _ !== null && !N) && T(e, E);
  }
  return !1;
}
function st(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !R?.includes(e))
    for (var s = 0; s < r.length; s++) {
      var l = r[s];
      (l.f & S) !== 0 ? st(
        /** @type {Derived} */
        l,
        t,
        !1
      ) : t === l && (n ? T(l, O) : (l.f & E) !== 0 && T(l, F), _e(
        /** @type {Effect} */
        l
      ));
    }
}
function it(e) {
  var t = m, n = b, r = x, s = h, l = N, u = R, a = V, i = L, f = U, o = e.f;
  m = /** @type {null | Value[]} */
  null, b = 0, x = null, N = (o & k) !== 0 && (L || !G || h === null), h = (o & (ne | z)) === 0 ? e : null, R = null, ce(e.ctx), L = !1, U = ++ee, e.ac !== null && (Je(() => {
    e.ac.abort(Te);
  }), e.ac = null);
  try {
    e.f |= me;
    var c = (
      /** @type {Function} */
      e.fn
    ), p = c(), v = e.deps;
    if (m !== null) {
      var d;
      if (de(e, b), v !== null && b > 0)
        for (v.length = b + m.length, d = 0; d < m.length; d++)
          v[b + d] = m[d];
      else
        e.deps = v = m;
      if (!N || // Deriveds that already have reactions can cleanup, so we still add them as reactions
      (o & S) !== 0 && /** @type {import('#client').Derived} */
      e.reactions !== null)
        for (d = b; d < v.length; d++)
          (v[d].reactions ??= []).push(e);
    } else v !== null && b < v.length && (de(e, b), v.length = b);
    if (re() && x !== null && !L && v !== null && (e.f & (S | F | O)) === 0)
      for (d = 0; d < /** @type {Source[]} */
      x.length; d++)
        st(
          x[d],
          /** @type {Effect} */
          e
        );
    return s !== null && s !== e && (ee++, x !== null && (r === null ? r = x : r.push(.../** @type {Source[]} */
    x))), (e.f & B) !== 0 && (e.f ^= B), p;
  } catch (q) {
    return Lt(q);
  } finally {
    e.f ^= me, m = t, b = n, x = r, h = s, N = l, R = u, ce(a), L = i, U = f;
  }
}
function rn(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = yt.call(n, e);
    if (r !== -1) {
      var s = n.length - 1;
      s === 0 ? n = t.reactions = null : (n[r] = n[s], n.pop());
    }
  }
  n === null && (t.f & S) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (m === null || !m.includes(t)) && (T(t, F), (t.f & (k | ae)) === 0 && (t.f ^= ae), He(
    /** @type {Derived} **/
    t
  ), de(
    /** @type {Derived} **/
    t,
    0
  ));
}
function de(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      rn(e, n[r]);
}
function K(e) {
  var t = e.f;
  if ((t & Y) === 0) {
    T(e, E);
    var n = _, r = G;
    _ = e, G = !0;
    try {
      (t & te) !== 0 ? Xt(e) : tt(e), et(e);
      var s = it(e);
      e.teardown = typeof s == "function" ? s : null, e.wv = rt;
      var l;
      qe && _t && (e.f & O) !== 0 && e.deps;
    } finally {
      G = r, _ = n;
    }
  }
}
function I(e) {
  var t = e.f, n = (t & S) !== 0;
  if (h !== null && !L) {
    var r = _ !== null && (_.f & Y) !== 0;
    if (!r && !R?.includes(e)) {
      var s = h.deps;
      if ((h.f & me) !== 0)
        e.rv < ee && (e.rv = ee, m === null && s !== null && s[b] === e ? b++ : m === null ? m = [e] : (!N || !m.includes(e)) && m.push(e));
      else {
        (h.deps ??= []).push(e);
        var l = e.reactions;
        l === null ? e.reactions = [h] : l.includes(h) || l.push(h);
      }
    }
  } else if (n && /** @type {Derived} */
  e.deps === null && /** @type {Derived} */
  e.effects === null) {
    var u = (
      /** @type {Derived} */
      e
    ), a = u.parent;
    a !== null && (a.f & k) === 0 && (u.f ^= k);
  }
  if (Z) {
    if (M.has(e))
      return M.get(e);
    if (n) {
      u = /** @type {Derived} */
      e;
      var i = u.v;
      return ((u.f & E) === 0 && u.reactions !== null || ut(u)) && (i = Oe(u)), M.set(u, i), i;
    }
  } else if (n) {
    if (u = /** @type {Derived} */
    e, $?.has(u))
      return $.get(u);
    ge(u) && Ge(u);
  }
  if ((e.f & B) !== 0)
    throw e.v;
  return e.v;
}
function ut(e) {
  if (e.v === w) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (M.has(t) || (t.f & S) !== 0 && ut(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
const ln = -7169;
function T(e, t) {
  e.f = e.f & ln | t;
}
function sn(e) {
  var t = document.createElement("template");
  return t.innerHTML = e.replaceAll("<!>", "<!---->"), t.content;
}
function un(e, t) {
  var n = (
    /** @type {Effect} */
    _
  );
  n.nodes_start === null && (n.nodes_start = e, n.nodes_end = t);
}
// @__NO_SIDE_EFFECTS__
function ft(e, t) {
  var n = (t & wt) !== 0, r, s = !e.startsWith("<!>");
  return () => {
    r === void 0 && (r = sn(s ? e : "<!>" + e), r = /** @type {Node} */
    /* @__PURE__ */ Ze(r));
    var l = (
      /** @type {TemplateNode} */
      n || $t ? document.importNode(r, !0) : r.cloneNode(!0)
    );
    return un(l, l), l;
  };
}
function at(e, t) {
  e !== null && e.before(
    /** @type {Node} */
    t
  );
}
function ot(e, t) {
  var n = t == null ? "" : typeof t == "object" ? t + "" : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = n + "");
}
let ie = !1;
function fn(e) {
  var t = ie;
  try {
    return ie = !1, [e(), ie];
  } finally {
    ie = t;
  }
}
function ct(e, t, n, r) {
  var s = !be || (n & dt) !== 0, l = (n & gt) !== 0, u = (
    /** @type {V} */
    r
  ), a = !0, i = () => (a && (a = !1, u = /** @type {V} */
  r), u), f;
  {
    var o = fe in e || Rt in e;
    f = ue(e, t)?.set ?? (o && t in e ? (g) => e[t] = g : void 0);
  }
  var c, p = !1;
  [c, p] = fn(() => (
    /** @type {V} */
    e[t]
  )), c === void 0 && r !== void 0 && (c = i(), f && (s && Nt(), f(c)));
  var v;
  if (s ? v = () => {
    var g = (
      /** @type {V} */
      e[t]
    );
    return g === void 0 ? i() : (a = !0, g);
  } : v = () => {
    var g = (
      /** @type {V} */
      e[t]
    );
    return g !== void 0 && (u = /** @type {V} */
    void 0), g === void 0 ? u : g;
  }, s && (n & pt) === 0)
    return v;
  if (f) {
    var d = e.$$legacy;
    return (
      /** @type {() => V} */
      (function(g, se) {
        return arguments.length > 0 ? ((!s || !se || d || p) && f(se ? v() : g), g) : v();
      })
    );
  }
  var q = !1, A = /* @__PURE__ */ Ye(() => (q = !1, v()));
  I(A);
  var le = (
    /** @type {Effect} */
    _
  );
  return (
    /** @type {() => V} */
    (function(g, se) {
      if (arguments.length > 0) {
        const Ae = se ? I(A) : s && l ? H(g) : g;
        return C(A, Ae), q = !0, u !== void 0 && (u = Ae), g;
      }
      return Z && q || (le.f & Y) !== 0 ? A.v : I(A);
    })
  );
}
var an = /* @__PURE__ */ ft('<section class="strongholds-app svelte-1c44y49"><h1> </h1> <p>View your strongholds and settlements.</p></section>');
function on(e, t) {
  let n = ct(t, "name", 8, "Strongholds");
  var r = an(), s = he(r), l = he(s);
  Xe(() => ot(l, n())), at(e, r);
}
var cn = /* @__PURE__ */ ft('<section class="strongholds-mgmt-app svelte-po06u7"><h1> </h1> <p>Manage strongholds (GM only).</p></section>');
function vn(e, t) {
  let n = ct(t, "name", 8, "Strongholds Management");
  var r = cn(), s = he(r), l = he(s);
  Xe(() => ot(l, n())), at(e, r);
}
class vt extends Application {
  constructor() {
    super(...arguments), this.component = null;
  }
  static get defaultOptions() {
    return {
      ...super.defaultOptions,
      template: "modules/strongholds/templates/svelte-app.html",
      popOut: !0,
      width: 600,
      height: 400
    };
  }
  render(t, n) {
    const r = super.render(t, n), s = document.getElementById(this.options.id), l = this.options.svelte;
    return s && !this.component && l && (this.component = new l({ target: s })), r;
  }
}
class _n extends vt {
}
class hn extends vt {
}
Hooks.once("init", () => {
  console.log("Strongholds | init");
});
Hooks.once("ready", () => {
  console.log("Strongholds | ready");
});
Hooks.on("getSceneControlButtons", (e) => {
  const t = game.user?.isGM, n = [
    {
      name: "view-strongholds",
      title: "View Strongholds",
      icon: "fas fa-eye",
      onClick: () => new _n({ id: "strongholds-app", title: "Strongholds", svelte: on }).render(!0),
      button: !0
    },
    t ? {
      name: "edit-strongholds",
      title: "Manage Strongholds",
      icon: "fas fa-edit",
      onClick: () => new hn({ id: "strongholds-mgmt", title: "Strongholds Management", svelte: vn }).render(!0),
      button: !0
    } : null
  ].filter(Boolean);
  e.push({
    name: "strongholds",
    title: "Strongholds",
    icon: "fas fa-home",
    layer: "controls",
    tools: n,
    activeTool: null
  });
});
